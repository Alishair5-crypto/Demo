import {
  pgTable,
  serial,
  varchar,
  text,
  timestamp,
  boolean,
  integer,
  decimal,
  jsonb,
  pgEnum,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ─── Enums ────────────────────────────────────────────────────────────────────

export const userRoleEnum = pgEnum("user_role", ["admin", "manager", "agent", "viewer"]);
export const subscriptionPlanEnum = pgEnum("subscription_plan", ["trial", "silver", "gold", "diamond"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", ["active", "expired", "cancelled", "pending"]);
export const orderStatusEnum = pgEnum("order_status", ["pending", "confirmed", "processing", "delivered", "completed", "cancelled"]);
export const paymentStatusEnum = pgEnum("payment_status", ["pending", "completed", "failed", "refunded"]);
export const paymentMethodEnum = pgEnum("payment_method", ["jazzcash", "easypaisa", "stripe", "bank_transfer"]);
export const notificationTypeEnum = pgEnum("notification_type", ["order", "customer", "payment", "subscription", "ai_event", "system"]);
export const messageDirectionEnum = pgEnum("message_direction", ["inbound", "outbound"]);
export const messageStatusEnum = pgEnum("message_status", ["sent", "delivered", "read", "failed"]);
export const leadStatusEnum = pgEnum("lead_status", ["new", "qualified", "unqualified", "converted", "lost"]);
export const knowledgeBaseTypeEnum = pgEnum("knowledge_base_type", ["product", "faq", "pricing", "company", "policy"]);
export const activityTypeEnum = pgEnum("activity_type", ["create", "update", "delete", "login", "logout", "api_call", "ai_response"]);

// ─── Users ────────────────────────────────────────────────────────────────────

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  role: userRoleEnum("role").default("admin").notNull(),
  companyName: varchar("company_name", { length: 255 }),
  companyLogo: varchar("company_logo", { length: 500 }),
  phone: varchar("phone", { length: 20 }),
  timezone: varchar("timezone", { length: 100 }).default("UTC"),
  language: varchar("language", { length: 10 }).default("en"),
  theme: varchar("theme", { length: 10 }).default("dark"),
  isActive: boolean("is_active").default(true),
  emailVerified: boolean("email_verified").default(false),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Subscriptions ────────────────────────────────────────────────────────────

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  plan: subscriptionPlanEnum("plan").default("trial").notNull(),
  status: subscriptionStatusEnum("status").default("active").notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date"),
  trialEndsAt: timestamp("trial_ends_at"),
  monthlyPrice: decimal("monthly_price", { precision: 10, scale: 2 }),
  features: jsonb("features"),
  autoRenew: boolean("auto_renew").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Customers ────────────────────────────────────────────────────────────────

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 20 }).notNull(),
  whatsappNumber: varchar("whatsapp_number", { length: 20 }),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  country: varchar("country", { length: 100 }).default("Pakistan"),
  tags: jsonb("tags").$type<string[]>().default([]),
  notes: text("notes"),
  leadStatus: leadStatusEnum("lead_status").default("new"),
  totalOrders: integer("total_orders").default(0),
  totalSpent: decimal("total_spent", { precision: 12, scale: 2 }).default("0"),
  lastContactedAt: timestamp("last_contacted_at"),
  isActive: boolean("is_active").default(true),
  source: varchar("source", { length: 100 }).default("manual"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Orders ───────────────────────────────────────────────────────────────────

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  customerId: integer("customer_id").notNull().references(() => customers.id, { onDelete: "restrict" }),
  orderNumber: varchar("order_number", { length: 50 }).notNull().unique(),
  status: orderStatusEnum("status").default("pending").notNull(),
  items: jsonb("items").$type<Array<{ productId?: number; name: string; qty: number; price: number; total: number }>>().notNull(),
  subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
  tax: decimal("tax", { precision: 12, scale: 2 }).default("0"),
  discount: decimal("discount", { precision: 12, scale: 2 }).default("0"),
  total: decimal("total", { precision: 12, scale: 2 }).notNull(),
  notes: text("notes"),
  deliveryAddress: text("delivery_address"),
  paymentStatus: paymentStatusEnum("payment_status").default("pending"),
  paymentMethod: paymentMethodEnum("payment_method"),
  deliveredAt: timestamp("delivered_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Products (Knowledge Base items) ─────────────────────────────────────────

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  sku: varchar("sku", { length: 100 }),
  description: text("description"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  category: varchar("category", { length: 100 }),
  stock: integer("stock").default(0),
  imageUrl: varchar("image_url", { length: 500 }),
  isActive: boolean("is_active").default(true),
  tags: jsonb("tags").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── WhatsApp Conversations ───────────────────────────────────────────────────

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
  whatsappNumber: varchar("whatsapp_number", { length: 20 }).notNull(),
  contactName: varchar("contact_name", { length: 200 }),
  lastMessage: text("last_message"),
  lastMessageAt: timestamp("last_message_at"),
  unreadCount: integer("unread_count").default(0),
  isAiManaged: boolean("is_ai_managed").default(true),
  leadStatus: leadStatusEnum("lead_status").default("new"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── WhatsApp Messages ────────────────────────────────────────────────────────

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  direction: messageDirectionEnum("direction").notNull(),
  messageType: varchar("message_type", { length: 50 }).default("text"),
  content: text("content").notNull(),
  mediaUrl: varchar("media_url", { length: 500 }),
  status: messageStatusEnum("status").default("sent"),
  isAiGenerated: boolean("is_ai_generated").default(false),
  whatsappMessageId: varchar("whatsapp_message_id", { length: 200 }),
  sentAt: timestamp("sent_at").defaultNow(),
  deliveredAt: timestamp("delivered_at"),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Knowledge Base ───────────────────────────────────────────────────────────

export const knowledgeBase = pgTable("knowledge_base", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: knowledgeBaseTypeEnum("type").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  tags: jsonb("tags").$type<string[]>().default([]),
  isActive: boolean("is_active").default(true),
  priority: integer("priority").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Notifications ────────────────────────────────────────────────────────────

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: notificationTypeEnum("type").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Payments ─────────────────────────────────────────────────────────────────

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  subscriptionId: integer("subscription_id").references(() => subscriptions.id, { onDelete: "set null" }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("PKR"),
  method: paymentMethodEnum("method").notNull(),
  status: paymentStatusEnum("status").default("pending"),
  transactionId: varchar("transaction_id", { length: 200 }),
  invoiceNumber: varchar("invoice_number", { length: 100 }),
  metadata: jsonb("metadata"),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Activity Logs ────────────────────────────────────────────────────────────

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  type: activityTypeEnum("type").notNull(),
  entity: varchar("entity", { length: 100 }),
  entityId: integer("entity_id"),
  description: text("description").notNull(),
  ipAddress: varchar("ip_address", { length: 50 }),
  userAgent: text("user_agent"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Settings ─────────────────────────────────────────────────────────────────

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  whatsappPhoneId: varchar("whatsapp_phone_id", { length: 200 }),
  whatsappToken: varchar("whatsapp_token", { length: 500 }),
  whatsappWebhookVerifyToken: varchar("whatsapp_webhook_verify_token", { length: 200 }),
  openaiApiKey: varchar("openai_api_key", { length: 200 }),
  openaiModel: varchar("openai_model", { length: 100 }).default("gpt-4o-mini"),
  openaiSystemPrompt: text("openai_system_prompt"),
  googleSheetsId: varchar("google_sheets_id", { length: 200 }),
  googleServiceAccountJson: text("google_service_account_json"),
  jazzcashMerchantId: varchar("jazzcash_merchant_id", { length: 100 }),
  jazzcashPassword: varchar("jazzcash_password", { length: 200 }),
  easypaisaStoreId: varchar("easypaisa_store_id", { length: 100 }),
  easypaisaHashKey: varchar("easypaisa_hash_key", { length: 200 }),
  stripePublishableKey: varchar("stripe_publishable_key", { length: 200 }),
  stripeSecretKey: varchar("stripe_secret_key", { length: 200 }),
  aiAutoReply: boolean("ai_auto_reply").default(true),
  aiLeadQualification: boolean("ai_lead_qualification").default(true),
  aiFollowUp: boolean("ai_follow_up").default(true),
  followUpDelayHours: integer("follow_up_delay_hours").default(24),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Broadcast Campaigns ──────────────────────────────────────────────────────

export const broadcasts = pgTable("broadcasts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  message: text("message").notNull(),
  recipientCount: integer("recipient_count").default(0),
  sentCount: integer("sent_count").default(0),
  failedCount: integer("failed_count").default(0),
  status: varchar("status", { length: 50 }).default("draft"),
  scheduledAt: timestamp("scheduled_at"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── AI Conversations Memory ──────────────────────────────────────────────────

export const aiMemory = pgTable("ai_memory", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  messages: jsonb("messages").$type<Array<{ role: string; content: string; timestamp: string }>>().default([]),
  summary: text("summary"),
  customerIntent: varchar("customer_intent", { length: 200 }),
  qualificationScore: integer("qualification_score").default(0),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Relations ────────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ many, one }) => ({
  subscriptions: many(subscriptions),
  customers: many(customers),
  orders: many(orders),
  conversations: many(conversations),
  notifications: many(notifications),
  payments: many(payments),
  activityLogs: many(activityLogs),
  settings: one(settings),
  knowledgeBase: many(knowledgeBase),
  products: many(products),
  broadcasts: many(broadcasts),
}));

export const customersRelations = relations(customers, ({ one, many }) => ({
  user: one(users, { fields: [customers.userId], references: [users.id] }),
  orders: many(orders),
  conversations: many(conversations),
}));

export const ordersRelations = relations(orders, ({ one }) => ({
  user: one(users, { fields: [orders.userId], references: [users.id] }),
  customer: one(customers, { fields: [orders.customerId], references: [customers.id] }),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, { fields: [conversations.userId], references: [users.id] }),
  customer: one(customers, { fields: [conversations.customerId], references: [customers.id] }),
  messages: many(messages),
  aiMemory: one(aiMemory),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, { fields: [messages.conversationId], references: [conversations.id] }),
  user: one(users, { fields: [messages.userId], references: [users.id] }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one, many }) => ({
  user: one(users, { fields: [subscriptions.userId], references: [users.id] }),
  payments: many(payments),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, { fields: [payments.userId], references: [users.id] }),
  subscription: one(subscriptions, { fields: [payments.subscriptionId], references: [subscriptions.id] }),
}));

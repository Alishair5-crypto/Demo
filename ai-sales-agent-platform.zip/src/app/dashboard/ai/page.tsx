"use client";

import { useState, useRef, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Bot, Send, RefreshCw, Sparkles, Brain, MessageSquare, Zap, Settings, Copy, ThumbsUp, X } from "lucide-react";
import toast from "react-hot-toast";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

const QUICK_PROMPTS = [
  "What products do you recommend for a new customer?",
  "How should I qualify a lead who is interested in premium products?",
  "Write a follow-up message for a customer who hasn't responded in 3 days",
  "How do I handle a complaint about late delivery?",
  "Generate a product pitch for our best-selling item",
  "What are the best strategies for upselling?",
];

export default function AIPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [convHistory, setConvHistory] = useState<{ role: string; content: string }[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Load settings
    fetch("/api/settings").then(r => r.json()).then(d => {
      if (d.settings?.openaiSystemPrompt) setSystemPrompt(d.settings.openaiSystemPrompt);
    }).catch(() => {});
  }, []);

  const sendMessage = async (content: string) => {
    if (!content.trim() || loading) return;

    const userMsg: ChatMessage = { role: "user", content, timestamp: new Date().toISOString() };
    const updatedHistory = [...convHistory, { role: "user", content }];

    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content, conversationHistory: convHistory }),
      });
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || "AI error");
        return;
      }

      const aiMsg: ChatMessage = { role: "assistant", content: data.reply, timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, aiMsg]);
      setConvHistory([...updatedHistory, { role: "assistant", content: data.reply }]);
    } catch { toast.error("Network error"); }
    finally { setLoading(false); }
  };

  const clearChat = () => {
    setMessages([]);
    setConvHistory([]);
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success("Copied!");
  };

  const featureCards = [
    { icon: "🎯", title: "Lead Qualification", desc: "AI analyzes conversations and scores leads", color: "#6366f1" },
    { icon: "🛍️", title: "Product Recommendation", desc: "Suggests products based on customer needs", color: "#8b5cf6" },
    { icon: "💬", title: "FAQ Answering", desc: "Answers common questions from your knowledge base", color: "#22c55e" },
    { icon: "🧠", title: "Conversation Memory", desc: "Remembers context across the conversation", color: "#f59e0b" },
    { icon: "📝", title: "Prompt Management", desc: "Customize the AI's personality and behavior", color: "#ec4899" },
    { icon: "🔍", title: "Knowledge Base Search", desc: "Searches your products, FAQs, and policies", color: "#3b82f6" },
  ];

  return (
    <DashboardLayout title="AI Assistant">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 20, height: "calc(100vh - 120px)" }}>

        {/* Chat Area */}
        <div style={{ display: "flex", flexDirection: "column", background: "rgba(22,27,42,0.7)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 16, overflow: "hidden" }}>
          {/* Header */}
          <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", gap: 12 }}>
            <div className="animated-gradient" style={{ width: 36, height: 36, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Bot size={18} color="white" />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 700, color: "white" }}>AI Sales Assistant</div>
              <div style={{ fontSize: 11, color: "rgb(100,116,139)", display: "flex", alignItems: "center", gap: 4 }}>
                <div className="pulse-dot" style={{ width: 6, height: 6, background: "#22c55e", color: "#22c55e" }} />
                Powered by OpenAI GPT
              </div>
            </div>
            <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
              <button onClick={() => setShowSettings(!showSettings)} style={{ background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "rgb(148,163,184)" }}>
                <Settings size={14} />
              </button>
              {messages.length > 0 && (
                <button onClick={clearChat} style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 8, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#ef4444" }}>
                  <RefreshCw size={14} />
                </button>
              )}
            </div>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div style={{ padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(30,35,55,0.4)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: "white", textTransform: "uppercase", letterSpacing: "0.05em" }}>System Prompt</span>
                <button onClick={() => setShowSettings(false)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={14} /></button>
              </div>
              <textarea
                className="input-field"
                value={systemPrompt}
                onChange={e => setSystemPrompt(e.target.value)}
                rows={3}
                style={{ fontSize: 12, resize: "none" }}
                placeholder="Customize the AI's behavior..."
              />
              <button
                onClick={async () => {
                  await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ openaiSystemPrompt: systemPrompt }) });
                  toast.success("Prompt saved!");
                  setShowSettings(false);
                }}
                className="btn-primary"
                style={{ marginTop: 8, padding: "7px 16px", fontSize: 12 }}
              >
                Save Prompt
              </button>
            </div>
          )}

          {/* Messages */}
          <div style={{ flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: 16 }}>
            {messages.length === 0 ? (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
                <div style={{ width: 64, height: 64, borderRadius: 18, background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(139,92,246,0.2))", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16, fontSize: 28 }}>🤖</div>
                <h3 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 6 }}>AI Sales Assistant</h3>
                <p style={{ fontSize: 13, color: "rgb(100,116,139)", marginBottom: 20, maxWidth: 300 }}>Ask me anything about sales, customers, products, or let me generate messages for you.</p>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, width: "100%", maxWidth: 400 }}>
                  {QUICK_PROMPTS.slice(0, 4).map((p, i) => (
                    <button key={i} onClick={() => sendMessage(p)} style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 10, padding: "10px 12px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 11, textAlign: "left", lineHeight: 1.4, fontWeight: 500 }}>{p}</button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m, i) => (
                <div key={i} style={{ display: "flex", gap: 12, flexDirection: m.role === "user" ? "row-reverse" : "row" }}>
                  <div style={{ width: 32, height: 32, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, background: m.role === "user" ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "rgba(245,158,11,0.2)" }}>
                    {m.role === "user" ? "👤" : "🤖"}
                  </div>
                  <div style={{ maxWidth: "75%", position: "relative" }}>
                    <div style={{
                      background: m.role === "user" ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "rgba(30,35,55,0.8)",
                      border: m.role === "user" ? "none" : "1px solid rgba(255,255,255,0.06)",
                      borderRadius: m.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                      padding: "12px 16px",
                      color: "white",
                      fontSize: 13,
                      lineHeight: 1.6,
                      whiteSpace: "pre-wrap",
                    }}>
                      {m.content}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4, justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
                      <span style={{ fontSize: 10, color: "rgb(100,116,139)" }}>{new Date(m.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                      {m.role === "assistant" && (
                        <button onClick={() => copyMessage(m.content)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer", display: "flex", alignItems: "center", gap: 3, fontSize: 11 }}>
                          <Copy size={11} /> Copy
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
            {loading && (
              <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", background: "rgba(245,158,11,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>🤖</div>
                <div style={{ background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: "18px 18px 18px 4px", padding: "14px 16px" }}>
                  <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
                    {[0, 1, 2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#6366f1", animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }} />)}
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div style={{ padding: "14px 20px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
              <textarea
                className="input-field"
                placeholder="Ask the AI anything... (Enter to send, Shift+Enter for new line)"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
                rows={2}
                style={{ flex: 1, resize: "none", fontSize: 13 }}
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={loading || !input.trim()}
                className="btn-primary"
                style={{ width: 40, height: 40, padding: 0, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, opacity: (loading || !input.trim()) ? 0.6 : 1 }}
              >
                {loading ? <RefreshCw size={16} style={{ animation: "spin 1s linear infinite" }} /> : <Send size={16} />}
              </button>
            </div>
            <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
              {QUICK_PROMPTS.slice(0, 3).map((p, i) => (
                <button key={i} onClick={() => sendMessage(p)} style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 6, padding: "3px 10px", color: "rgb(100,116,139)", cursor: "pointer", fontSize: 11, whiteSpace: "nowrap" }}>
                  <Sparkles size={9} style={{ display: "inline", marginRight: 4 }} />
                  {p.slice(0, 30)}...
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* AI Features */}
          <div className="glass-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
              <Brain size={16} style={{ color: "#8b5cf6" }} /> AI Capabilities
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {featureCards.map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", background: "rgba(30,35,55,0.5)", borderRadius: 10, border: "1px solid rgba(255,255,255,0.04)" }}>
                  <span style={{ fontSize: 18 }}>{f.icon}</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "white" }}>{f.title}</div>
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{f.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="glass-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
              <Zap size={16} style={{ color: "#f59e0b" }} /> Quick Prompts
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {QUICK_PROMPTS.map((p, i) => (
                <button key={i} onClick={() => sendMessage(p)} style={{ background: "rgba(30,35,55,0.5)", border: "1px solid rgba(255,255,255,0.04)", borderRadius: 8, padding: "10px 12px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 12, textAlign: "left", fontWeight: 500, lineHeight: 1.4, transition: "all 0.2s" }}>
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="glass-card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}>
              <MessageSquare size={16} style={{ color: "#22c55e" }} /> Session Stats
            </h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                { label: "Messages", value: messages.length, color: "#6366f1" },
                { label: "AI Replies", value: messages.filter(m => m.role === "assistant").length, color: "#f59e0b" },
              ].map((s, i) => (
                <div key={i} style={{ textAlign: "center", background: "rgba(30,35,55,0.5)", borderRadius: 10, padding: "12px 8px" }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes bounce { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; } 40% { transform: scale(1); opacity: 1; } }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </DashboardLayout>
  );
}

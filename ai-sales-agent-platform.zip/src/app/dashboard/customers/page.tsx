"use client";

import { useState, useEffect, useCallback } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Users, Plus, Search, Filter, Trash2, Edit, Eye, Download, Upload, X, Phone, Mail, MapPin, Tag } from "lucide-react";
import toast from "react-hot-toast";

interface Customer {
  id: number;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string;
  whatsappNumber: string | null;
  address: string | null;
  city: string | null;
  country: string | null;
  tags: string[];
  notes: string | null;
  leadStatus: string;
  totalOrders: number;
  totalSpent: string;
  createdAt: string;
  isActive: boolean;
}

const LEAD_STATUS_COLORS: Record<string, string> = {
  new: "info", qualified: "success", unqualified: "warning", converted: "purple", lost: "danger",
};

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [leadStatus, setLeadStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editCustomer, setEditCustomer] = useState<Customer | null>(null);
  const [viewCustomer, setViewCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", whatsappNumber: "", address: "", city: "", country: "Pakistan", tags: "", notes: "", leadStatus: "new" });
  const [submitting, setSubmitting] = useState(false);

  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "20" });
      if (search) params.set("search", search);
      if (leadStatus) params.set("leadStatus", leadStatus);
      const res = await fetch(`/api/customers?${params}`);
      const data = await res.json();
      setCustomers(data.customers || []);
      setTotal(data.total || 0);
    } catch { toast.error("Failed to load customers"); }
    finally { setLoading(false); }
  }, [page, search, leadStatus]);

  useEffect(() => { fetchCustomers(); }, [fetchCustomers]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const body = { ...form, tags: form.tags.split(",").map(t => t.trim()).filter(Boolean) };
      const url = editCustomer ? `/api/customers/${editCustomer.id}` : "/api/customers";
      const method = editCustomer ? "PATCH" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(editCustomer ? "Customer updated!" : "Customer added!");
      setShowModal(false);
      setEditCustomer(null);
      setForm({ firstName: "", lastName: "", email: "", phone: "", whatsappNumber: "", address: "", city: "", country: "Pakistan", tags: "", notes: "", leadStatus: "new" });
      fetchCustomers();
    } catch { toast.error("Failed to save"); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this customer?")) return;
    const res = await fetch(`/api/customers/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted"); fetchCustomers(); }
    else toast.error("Failed to delete");
  };

  const openEdit = (c: Customer) => {
    setEditCustomer(c);
    setForm({ firstName: c.firstName, lastName: c.lastName, email: c.email || "", phone: c.phone, whatsappNumber: c.whatsappNumber || "", address: c.address || "", city: c.city || "", country: c.country || "Pakistan", tags: (c.tags || []).join(", "), notes: c.notes || "", leadStatus: c.leadStatus });
    setShowModal(true);
  };

  return (
    <DashboardLayout title="Customers">
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <Users size={24} style={{ color: "#8b5cf6" }} /> Customers
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>{total.toLocaleString()} total customers</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, padding: "9px 16px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 13, fontWeight: 500 }}>
            <Upload size={15} /> Import
          </button>
          <button style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, padding: "9px 16px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 13, fontWeight: 500 }}>
            <Download size={15} /> Export
          </button>
          <button onClick={() => { setEditCustomer(null); setForm({ firstName: "", lastName: "", email: "", phone: "", whatsappNumber: "", address: "", city: "", country: "Pakistan", tags: "", notes: "", leadStatus: "new" }); setShowModal(true); }} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Plus size={16} /> Add Customer
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="glass-card" style={{ padding: 16, marginBottom: 20, display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
        <div style={{ flex: 1, minWidth: 200, position: "relative" }}>
          <Search size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
          <input className="input-field" placeholder="Search by name, email, phone..." value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} style={{ paddingLeft: 36 }} />
        </div>
        <select className="input-field" value={leadStatus} onChange={e => { setLeadStatus(e.target.value); setPage(1); }} style={{ width: 160 }}>
          <option value="">All Statuses</option>
          <option value="new">New</option>
          <option value="qualified">Qualified</option>
          <option value="unqualified">Unqualified</option>
          <option value="converted">Converted</option>
          <option value="lost">Lost</option>
        </select>
      </div>

      {/* Table */}
      <div className="glass-card" style={{ overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Customer</th>
                <th>Contact</th>
                <th>Lead Status</th>
                <th>Orders</th>
                <th>Total Spent</th>
                <th>Tags</th>
                <th>Joined</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array(8).fill(0).map((_, i) => (
                  <tr key={i}>
                    {Array(8).fill(0).map((_, j) => (
                      <td key={j}><div className="skeleton" style={{ height: 16, width: j === 0 ? 140 : 80 }} /></td>
                    ))}
                  </tr>
                ))
              ) : customers.length === 0 ? (
                <tr>
                  <td colSpan={8} style={{ textAlign: "center", padding: "60px 20px", color: "rgb(100,116,139)" }}>
                    <Users size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>No customers found</div>
                    <div style={{ fontSize: 13 }}>Add your first customer to get started</div>
                  </td>
                </tr>
              ) : (
                customers.map(c => (
                  <tr key={c.id}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white", flexShrink: 0 }}>
                          {c.firstName[0]}{c.lastName[0]}
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, color: "white", fontSize: 13 }}>{c.firstName} {c.lastName}</div>
                          <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{c.city || "—"}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                        <span style={{ fontSize: 12, color: "rgb(148,163,184)", display: "flex", alignItems: "center", gap: 4 }}><Phone size={10} />{c.phone}</span>
                        {c.email && <span style={{ fontSize: 12, color: "rgb(148,163,184)", display: "flex", alignItems: "center", gap: 4 }}><Mail size={10} />{c.email}</span>}
                      </div>
                    </td>
                    <td><span className={`badge-${LEAD_STATUS_COLORS[c.leadStatus] || "info"}`}>{c.leadStatus}</span></td>
                    <td><span style={{ fontWeight: 600, color: "white" }}>{c.totalOrders || 0}</span></td>
                    <td><span style={{ fontWeight: 700, color: "#22c55e" }}>PKR {parseFloat(c.totalSpent || "0").toLocaleString()}</span></td>
                    <td>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                        {(c.tags || []).slice(0, 2).map((tag, i) => (
                          <span key={i} style={{ background: "rgba(99,102,241,0.15)", color: "#6366f1", borderRadius: 6, padding: "2px 7px", fontSize: 11, fontWeight: 500 }}>{tag}</span>
                        ))}
                        {(c.tags || []).length > 2 && <span style={{ fontSize: 11, color: "rgb(100,116,139)" }}>+{c.tags.length - 2}</span>}
                      </div>
                    </td>
                    <td><span style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{new Date(c.createdAt).toLocaleDateString()}</span></td>
                    <td>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button onClick={() => setViewCustomer(c)} style={{ background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#3b82f6" }}><Eye size={13} /></button>
                        <button onClick={() => openEdit(c)} style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#6366f1" }}><Edit size={13} /></button>
                        <button onClick={() => handleDelete(c.id)} style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#ef4444" }}><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > 20 && (
          <div style={{ padding: "14px 20px", borderTop: "1px solid rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 13, color: "rgb(100,116,139)" }}>Showing {(page - 1) * 20 + 1}–{Math.min(page * 20, total)} of {total}</span>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} style={{ background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "6px 14px", color: "rgb(148,163,184)", cursor: page === 1 ? "not-allowed" : "pointer", fontSize: 13, opacity: page === 1 ? 0.5 : 1 }}>Prev</button>
              <button onClick={() => setPage(p => p + 1)} disabled={page * 20 >= total} style={{ background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "6px 14px", color: "rgb(148,163,184)", cursor: page * 20 >= total ? "not-allowed" : "pointer", fontSize: 13, opacity: page * 20 >= total ? 0.5 : 1 }}>Next</button>
            </div>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>{editCustomer ? "Edit Customer" : "Add New Customer"}</h2>
              <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>First Name *</label>
                  <input className="input-field" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Last Name *</label>
                  <input className="input-field" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Phone *</label>
                  <input className="input-field" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} required placeholder="+92 300 0000000" />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>WhatsApp</label>
                  <input className="input-field" value={form.whatsappNumber} onChange={e => setForm({ ...form, whatsappNumber: e.target.value })} placeholder="Same as phone if same" />
                </div>
                <div style={{ gridColumn: "1/-1" }}>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Email</label>
                  <input className="input-field" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>City</label>
                  <input className="input-field" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Lead Status</label>
                  <select className="input-field" value={form.leadStatus} onChange={e => setForm({ ...form, leadStatus: e.target.value })}>
                    <option value="new">New</option>
                    <option value="qualified">Qualified</option>
                    <option value="unqualified">Unqualified</option>
                    <option value="converted">Converted</option>
                    <option value="lost">Lost</option>
                  </select>
                </div>
                <div style={{ gridColumn: "1/-1" }}>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Address</label>
                  <input className="input-field" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
                </div>
                <div style={{ gridColumn: "1/-1" }}>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Tags (comma separated)</label>
                  <input className="input-field" value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} placeholder="vip, returning, hot-lead" />
                </div>
                <div style={{ gridColumn: "1/-1" }}>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Notes</label>
                  <textarea className="input-field" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} style={{ resize: "vertical" }} />
                </div>
              </div>
              <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: "11px", background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgb(148,163,184)", cursor: "pointer", fontSize: 14, fontWeight: 600 }}>Cancel</button>
                <button type="submit" disabled={submitting} className="btn-primary" style={{ flex: 2, padding: "11px" }}>{submitting ? "Saving..." : editCustomer ? "Update Customer" : "Add Customer"}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Modal */}
      {viewCustomer && (
        <div className="modal-overlay" onClick={() => setViewCustomer(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>Customer Profile</h2>
              <button onClick={() => setViewCustomer(null)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={20} /></button>
            </div>
            <div style={{ textAlign: "center", marginBottom: 24 }}>
              <div style={{ width: 72, height: 72, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, fontWeight: 700, color: "white", margin: "0 auto 12px" }}>
                {viewCustomer.firstName[0]}{viewCustomer.lastName[0]}
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 700, color: "white" }}>{viewCustomer.firstName} {viewCustomer.lastName}</h3>
              <span className={`badge-${LEAD_STATUS_COLORS[viewCustomer.leadStatus] || "info"}`}>{viewCustomer.leadStatus}</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {[
                { icon: <Phone size={14} />, label: "Phone", value: viewCustomer.phone },
                { icon: <Mail size={14} />, label: "Email", value: viewCustomer.email || "—" },
                { icon: <MapPin size={14} />, label: "City", value: viewCustomer.city || "—" },
                { icon: <Tag size={14} />, label: "Tags", value: (viewCustomer.tags || []).join(", ") || "—" },
              ].map((item, i) => (
                <div key={i} style={{ background: "rgba(30,35,55,0.6)", borderRadius: 10, padding: "12px 14px" }}>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginBottom: 4, display: "flex", alignItems: "center", gap: 5, textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 600 }}>{item.icon}{item.label}</div>
                  <div style={{ fontSize: 13, color: "white", fontWeight: 500 }}>{item.value}</div>
                </div>
              ))}
              <div style={{ gridColumn: "1/-1", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: "#22c55e" }}>{viewCustomer.totalOrders || 0}</div>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)", textTransform: "uppercase", letterSpacing: "0.05em" }}>Total Orders</div>
                </div>
                <div style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 10, padding: "12px 14px", textAlign: "center" }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: "#6366f1" }}>PKR {parseFloat(viewCustomer.totalSpent || "0").toLocaleString()}</div>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)", textTransform: "uppercase", letterSpacing: "0.05em" }}>Total Spent</div>
                </div>
              </div>
            </div>
            {viewCustomer.notes && (
              <div style={{ marginTop: 14, background: "rgba(30,35,55,0.6)", borderRadius: 10, padding: "12px 14px" }}>
                <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 600 }}>Notes</div>
                <div style={{ fontSize: 13, color: "rgb(148,163,184)", lineHeight: 1.6 }}>{viewCustomer.notes}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

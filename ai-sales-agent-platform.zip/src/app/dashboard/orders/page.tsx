"use client";

import { useState, useEffect, useCallback } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Package, Plus, Search, Trash2, Edit, X, ChevronDown, FileText } from "lucide-react";
import toast from "react-hot-toast";

interface OrderItem { name: string; qty: number; price: number; total: number; }
interface Order {
  id: number;
  orderNumber: string;
  status: string;
  items: OrderItem[];
  subtotal: string;
  tax: string;
  discount: string;
  total: string;
  paymentStatus: string;
  paymentMethod: string | null;
  notes: string | null;
  deliveryAddress: string | null;
  createdAt: string;
  customerId: number;
  customerFirstName: string | null;
  customerLastName: string | null;
  customerPhone: string | null;
}
interface Customer { id: number; firstName: string; lastName: string; phone: string; }

const STATUS_COLORS: Record<string, string> = { pending: "warning", confirmed: "info", processing: "purple", delivered: "success", completed: "success", cancelled: "danger" };
const PAYMENT_COLORS: Record<string, string> = { pending: "warning", completed: "success", failed: "danger", refunded: "info" };

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editOrder, setEditOrder] = useState<Order | null>(null);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ customerId: "", status: "pending", paymentMethod: "", notes: "", deliveryAddress: "", tax: "0", discount: "0" });
  const [items, setItems] = useState<OrderItem[]>([{ name: "", qty: 1, price: 0, total: 0 }]);

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "20" });
      if (statusFilter) params.set("status", statusFilter);
      const res = await fetch(`/api/orders?${params}`);
      const data = await res.json();
      setOrders(data.orders || []);
      setTotal(data.total || 0);
    } catch { toast.error("Failed to load orders"); }
    finally { setLoading(false); }
  }, [page, statusFilter]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  useEffect(() => {
    fetch("/api/customers?limit=100")
      .then(r => r.json())
      .then(d => setCustomers(d.customers || []))
      .catch(() => {});
  }, []);

  const updateItem = (i: number, field: keyof OrderItem, val: string | number) => {
    const updated = [...items];
    updated[i] = { ...updated[i], [field]: val };
    if (field === "qty" || field === "price") {
      updated[i].total = Number(updated[i].qty) * Number(updated[i].price);
    }
    setItems(updated);
  };

  const subtotal = items.reduce((s, item) => s + item.total, 0);
  const orderTotal = subtotal + Number(form.tax) - Number(form.discount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.customerId) { toast.error("Select a customer"); return; }
    if (items.some(i => !i.name)) { toast.error("All items need a name"); return; }
    setSubmitting(true);
    try {
      const body = { customerId: parseInt(form.customerId), items, tax: form.tax, discount: form.discount, notes: form.notes, deliveryAddress: form.deliveryAddress, paymentMethod: form.paymentMethod || undefined };
      const url = editOrder ? `/api/orders/${editOrder.id}` : "/api/orders";
      const method = editOrder ? "PATCH" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(editOrder ? "Order updated!" : "Order created!");
      setShowModal(false);
      setEditOrder(null);
      setItems([{ name: "", qty: 1, price: 0, total: 0 }]);
      setForm({ customerId: "", status: "pending", paymentMethod: "", notes: "", deliveryAddress: "", tax: "0", discount: "0" });
      fetchOrders();
    } catch { toast.error("Failed to save"); }
    finally { setSubmitting(false); }
  };

  const handleStatusUpdate = async (id: number, status: string) => {
    const res = await fetch(`/api/orders/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    if (res.ok) { toast.success("Status updated"); fetchOrders(); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this order?")) return;
    const res = await fetch(`/api/orders/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Deleted"); fetchOrders(); }
  };

  const statusCounts = { all: total, pending: 0, completed: 0, cancelled: 0 };

  return (
    <DashboardLayout title="Orders">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <Package size={24} style={{ color: "#ec4899" }} /> Orders
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>{total.toLocaleString()} total orders</p>
        </div>
        <button onClick={() => { setEditOrder(null); setShowModal(true); }} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <Plus size={16} /> Create Order
        </button>
      </div>

      {/* Status Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {["", "pending", "confirmed", "processing", "delivered", "completed", "cancelled"].map(s => (
          <button key={s} onClick={() => { setStatusFilter(s); setPage(1); }} style={{ padding: "7px 16px", borderRadius: 8, border: "1px solid", fontSize: 13, fontWeight: 600, cursor: "pointer", borderColor: statusFilter === s ? "#6366f1" : "rgba(255,255,255,0.08)", background: statusFilter === s ? "rgba(99,102,241,0.15)" : "rgba(30,35,55,0.6)", color: statusFilter === s ? "#6366f1" : "rgb(148,163,184)", textTransform: "capitalize" }}>
            {s || "All"}
          </button>
        ))}
      </div>

      <div className="glass-card" style={{ overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Order #</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array(8).fill(0).map((_, i) => (
                  <tr key={i}>{Array(8).fill(0).map((_, j) => <td key={j}><div className="skeleton" style={{ height: 16, width: j === 0 ? 100 : 70 }} /></td>)}</tr>
                ))
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={8} style={{ textAlign: "center", padding: "60px 20px", color: "rgb(100,116,139)" }}>
                    <Package size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                    <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>No orders found</div>
                    <div style={{ fontSize: 13 }}>Create your first order to get started</div>
                  </td>
                </tr>
              ) : (
                orders.map(o => (
                  <tr key={o.id}>
                    <td><span style={{ fontWeight: 700, color: "white", fontFamily: "monospace", fontSize: 12 }}>{o.orderNumber}</span></td>
                    <td><span style={{ fontWeight: 600, color: "rgb(203,213,225)", fontSize: 13 }}>{o.customerFirstName} {o.customerLastName}</span></td>
                    <td><span style={{ fontSize: 12, color: "rgb(148,163,184)" }}>{Array.isArray(o.items) ? o.items.length : 0} item(s)</span></td>
                    <td>
                      <select className={`badge-${STATUS_COLORS[o.status] || "info"}`} value={o.status} onChange={e => handleStatusUpdate(o.id, e.target.value)} style={{ background: "transparent", border: "none", cursor: "pointer", fontWeight: 600, fontSize: 12 }}>
                        {["pending", "confirmed", "processing", "delivered", "completed", "cancelled"].map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                    <td><span className={`badge-${PAYMENT_COLORS[o.paymentStatus] || "warning"}`}>{o.paymentStatus}</span></td>
                    <td><span style={{ fontWeight: 700, color: "#22c55e", fontSize: 13 }}>PKR {parseFloat(o.total).toLocaleString()}</span></td>
                    <td><span style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{new Date(o.createdAt).toLocaleDateString()}</span></td>
                    <td>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#6366f1" }}><FileText size={13} /></button>
                        <button onClick={() => handleDelete(o.id)} style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#ef4444" }}><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Order Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" style={{ maxWidth: 640 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>Create New Order</h2>
              <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Customer *</label>
                  <select className="input-field" value={form.customerId} onChange={e => setForm({ ...form, customerId: e.target.value })} required>
                    <option value="">Select customer...</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.firstName} {c.lastName} — {c.phone}</option>)}
                  </select>
                </div>

                {/* Items */}
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>Order Items *</label>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {items.map((item, i) => (
                      <div key={i} style={{ display: "grid", gridTemplateColumns: "3fr 1fr 1.5fr 1fr auto", gap: 8, alignItems: "center" }}>
                        <input className="input-field" placeholder="Product name" value={item.name} onChange={e => updateItem(i, "name", e.target.value)} required style={{ fontSize: 13 }} />
                        <input className="input-field" type="number" placeholder="Qty" min="1" value={item.qty} onChange={e => updateItem(i, "qty", parseInt(e.target.value) || 1)} style={{ fontSize: 13 }} />
                        <input className="input-field" type="number" placeholder="Price" min="0" step="0.01" value={item.price} onChange={e => updateItem(i, "price", parseFloat(e.target.value) || 0)} style={{ fontSize: 13 }} />
                        <div style={{ fontSize: 13, color: "#22c55e", fontWeight: 700, textAlign: "right" }}>PKR {item.total.toLocaleString()}</div>
                        {items.length > 1 && (
                          <button type="button" onClick={() => setItems(items.filter((_, j) => j !== i))} style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 7, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#ef4444" }}><X size={12} /></button>
                        )}
                      </div>
                    ))}
                    <button type="button" onClick={() => setItems([...items, { name: "", qty: 1, price: 0, total: 0 }])} style={{ background: "rgba(99,102,241,0.1)", border: "1px dashed rgba(99,102,241,0.3)", borderRadius: 8, padding: "8px", color: "#6366f1", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>+ Add Item</button>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Tax (PKR)</label>
                    <input className="input-field" type="number" min="0" value={form.tax} onChange={e => setForm({ ...form, tax: e.target.value })} />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Discount (PKR)</label>
                    <input className="input-field" type="number" min="0" value={form.discount} onChange={e => setForm({ ...form, discount: e.target.value })} />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Payment Method</label>
                    <select className="input-field" value={form.paymentMethod} onChange={e => setForm({ ...form, paymentMethod: e.target.value })}>
                      <option value="">Select...</option>
                      <option value="jazzcash">JazzCash</option>
                      <option value="easypaisa">EasyPaisa</option>
                      <option value="stripe">Stripe</option>
                      <option value="bank_transfer">Bank Transfer</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Delivery Address</label>
                  <input className="input-field" value={form.deliveryAddress} onChange={e => setForm({ ...form, deliveryAddress: e.target.value })} />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Notes</label>
                  <textarea className="input-field" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} style={{ resize: "vertical" }} />
                </div>

                {/* Total */}
                <div style={{ background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, padding: "14px 16px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 13, color: "rgb(148,163,184)" }}>Subtotal</span>
                    <span style={{ fontSize: 13, color: "white", fontWeight: 600 }}>PKR {subtotal.toLocaleString()}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 13, color: "rgb(148,163,184)" }}>Tax</span>
                    <span style={{ fontSize: 13, color: "white" }}>PKR {Number(form.tax).toLocaleString()}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid rgba(34,197,94,0.2)", paddingTop: 8, marginTop: 4 }}>
                    <span style={{ fontSize: 15, color: "white", fontWeight: 700 }}>Total</span>
                    <span style={{ fontSize: 18, color: "#22c55e", fontWeight: 800 }}>PKR {orderTotal.toLocaleString()}</span>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                  <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: "11px", background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgb(148,163,184)", cursor: "pointer", fontSize: 14, fontWeight: 600 }}>Cancel</button>
                  <button type="submit" disabled={submitting} className="btn-primary" style={{ flex: 2, padding: "11px" }}>{submitting ? "Creating..." : "Create Order"}</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

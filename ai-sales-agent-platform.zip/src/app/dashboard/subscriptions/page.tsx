"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Crown, Check, Zap, Star, Shield, X } from "lucide-react";
import toast from "react-hot-toast";

interface Subscription {
  id: number;
  plan: string;
  status: string;
  startDate: string;
  endDate: string | null;
  trialEndsAt: string | null;
  monthlyPrice: string | null;
  features: Record<string, unknown>;
  autoRenew: boolean;
}

interface Plan {
  name: string;
  monthlyPrice: number;
  features: Record<string, unknown>;
}

const PLAN_DETAILS = {
  silver: {
    icon: "🥈",
    gradient: "linear-gradient(135deg, #94a3b8, #64748b)",
    glow: "rgba(148,163,184,0.3)",
    highlights: ["500 Customers", "1,000 Orders", "5,000 WhatsApp Messages", "1,000 AI Responses", "3 Team Members", "Analytics & Reports", "Google Sheets Sync"],
  },
  gold: {
    icon: "🥇",
    gradient: "linear-gradient(135deg, #f59e0b, #d97706)",
    glow: "rgba(245,158,11,0.3)",
    highlights: ["2,000 Customers", "5,000 Orders", "20,000 WhatsApp Messages", "5,000 AI Responses", "10 Team Members", "Broadcast Campaigns", "Priority Support", "All Silver Features"],
  },
  diamond: {
    icon: "💎",
    gradient: "linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899)",
    glow: "rgba(99,102,241,0.4)",
    highlights: ["Unlimited Customers", "Unlimited Orders", "Unlimited WhatsApp Messages", "Unlimited AI Responses", "Unlimited Team Members", "Custom Integrations", "Dedicated Account Manager", "All Gold Features"],
  },
};

export default function SubscriptionsPage() {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [plans, setPlans] = useState<Record<string, Plan>>({});
  const [paymentHistory, setPaymentHistory] = useState<Array<{ id: number; amount: string; method: string; status: string; invoiceNumber: string | null; createdAt: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("jazzcash");
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetch("/api/subscriptions")
      .then(r => r.json())
      .then(data => {
        setSubscription(data.subscription);
        setPlans(data.plans || {});
        setPaymentHistory(data.paymentHistory || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const subscribe = async () => {
    if (!selectedPlan) return;
    setProcessing(true);
    try {
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan: selectedPlan, paymentMethod, transactionId: `TXN-${Date.now()}` }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      setSubscription(data.subscription);
      setShowModal(false);
      toast.success(`🎉 Successfully subscribed to ${selectedPlan} plan!`);
    } catch { toast.error("Failed to process"); }
    finally { setProcessing(false); }
  };

  const getDaysRemaining = () => {
    if (!subscription?.endDate) return null;
    const end = new Date(subscription.endDate);
    const now = new Date();
    const diff = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const daysLeft = getDaysRemaining();

  return (
    <DashboardLayout title="Subscription">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <Crown size={24} style={{ color: "#f59e0b" }} /> Subscription Plans
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Choose the plan that fits your business</p>
        </div>
      </div>

      {/* Current Plan */}
      {subscription && (
        <div className="glass-card" style={{ padding: 24, marginBottom: 28, background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <span style={{ fontSize: 36 }}>
                {subscription.plan === "trial" ? "🆓" : subscription.plan === "silver" ? "🥈" : subscription.plan === "gold" ? "🥇" : "💎"}
              </span>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "white", textTransform: "capitalize" }}>{subscription.plan} Plan</div>
                <div style={{ fontSize: 13, color: "rgb(148,163,184)" }}>
                  Status: <span style={{ color: subscription.status === "active" ? "#22c55e" : "#ef4444", fontWeight: 600 }}>{subscription.status}</span>
                  {subscription.monthlyPrice && <span style={{ marginLeft: 12 }}>· PKR {parseFloat(subscription.monthlyPrice).toLocaleString()}/month</span>}
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              {daysLeft !== null && (
                <div style={{ textAlign: "center", background: daysLeft <= 3 ? "rgba(239,68,68,0.1)" : "rgba(34,197,94,0.1)", border: `1px solid ${daysLeft <= 3 ? "rgba(239,68,68,0.2)" : "rgba(34,197,94,0.2)"}`, borderRadius: 10, padding: "10px 16px" }}>
                  <div style={{ fontSize: 22, fontWeight: 800, color: daysLeft <= 3 ? "#ef4444" : "#22c55e" }}>{daysLeft}</div>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>Days Left</div>
                </div>
              )}
              <button onClick={() => setShowModal(true)} className="btn-primary">
                {subscription.plan === "trial" ? "Upgrade Now" : "Change Plan"}
              </button>
            </div>
          </div>
          {subscription.plan === "trial" && daysLeft !== null && daysLeft <= 3 && (
            <div style={{ marginTop: 16, padding: "10px 14px", background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 10, fontSize: 13, color: "#f59e0b" }}>
              ⚠️ Your trial expires in {daysLeft} day(s). Upgrade to continue using all features.
            </div>
          )}
        </div>
      )}

      {/* Plans Grid */}
      <h2 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 16 }}>Available Plans</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 20, marginBottom: 28 }}>
        {/* Trial */}
        <div className="glass-card" style={{ padding: 24, border: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>🆓</div>
            <h3 style={{ fontSize: 18, fontWeight: 800, color: "white", marginBottom: 4 }}>Free Trial</h3>
            <div style={{ fontSize: 28, fontWeight: 900, color: "white" }}>PKR 0</div>
            <div style={{ fontSize: 13, color: "rgb(100,116,139)" }}>3 days only</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {["50 Customers", "100 Orders", "500 WhatsApp Messages", "100 AI Responses", "1 Team Member"].map((f, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "rgb(148,163,184)" }}>
                <Check size={14} style={{ color: "#22c55e", flexShrink: 0 }} /> {f}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 20, padding: "10px", background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 8, textAlign: "center", fontSize: 12, color: "#22c55e", fontWeight: 600 }}>
            ✓ Currently on this plan
          </div>
        </div>

        {/* Paid Plans */}
        {(["silver", "gold", "diamond"] as const).map((planKey, i) => {
          const plan = plans[planKey];
          const detail = PLAN_DETAILS[planKey];
          const isCurrent = subscription?.plan === planKey && subscription?.status === "active";
          const isPopular = planKey === "gold";
          return (
            <div key={planKey} style={{ position: "relative", padding: 24, borderRadius: 20, border: isPopular ? "2px solid #f59e0b" : "1px solid rgba(255,255,255,0.08)", background: "rgba(22,27,42,0.8)", boxShadow: `0 8px 30px ${detail.glow}` }}>
              {isPopular && (
                <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "linear-gradient(135deg, #f59e0b, #d97706)", color: "white", borderRadius: 20, padding: "4px 14px", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>
                  ⭐ Most Popular
                </div>
              )}
              <div style={{ textAlign: "center", marginBottom: 20 }}>
                <div style={{ fontSize: 36, marginBottom: 8 }}>{detail.icon}</div>
                <h3 style={{ fontSize: 18, fontWeight: 800, color: "white", marginBottom: 4, textTransform: "capitalize" }}>{planKey}</h3>
                {plan ? (
                  <>
                    <div style={{ fontSize: 30, fontWeight: 900, color: "white" }}>PKR {plan.monthlyPrice.toLocaleString()}</div>
                    <div style={{ fontSize: 13, color: "rgb(100,116,139)" }}>per month</div>
                  </>
                ) : (
                  <div className="skeleton" style={{ height: 40, width: 120, margin: "0 auto" }} />
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 20 }}>
                {detail.highlights.map((f, j) => (
                  <div key={j} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: j < 4 ? "white" : "rgb(148,163,184)" }}>
                    <div style={{ width: 18, height: 18, borderRadius: "50%", background: j < 4 ? detail.gradient : "rgba(34,197,94,0.15)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Check size={10} style={{ color: j < 4 ? "white" : "#22c55e" }} />
                    </div>
                    {f}
                  </div>
                ))}
              </div>
              {isCurrent ? (
                <div style={{ padding: "11px", background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, textAlign: "center", fontSize: 13, color: "#22c55e", fontWeight: 700 }}>
                  ✓ Active Plan
                </div>
              ) : (
                <button
                  onClick={() => { setSelectedPlan(planKey); setShowModal(true); }}
                  style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700, background: detail.gradient, color: "white", boxShadow: `0 6px 20px ${detail.glow}`, transition: "all 0.2s" }}
                >
                  Subscribe to {planKey.charAt(0).toUpperCase() + planKey.slice(1)} →
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Payment History */}
      {paymentHistory.length > 0 && (
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 16 }}>Payment History</h3>
          <table className="data-table">
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {paymentHistory.map(p => (
                <tr key={p.id}>
                  <td><span style={{ fontFamily: "monospace", fontSize: 12, color: "#6366f1" }}>{p.invoiceNumber || "—"}</span></td>
                  <td><span style={{ fontWeight: 700, color: "#22c55e" }}>PKR {parseFloat(p.amount).toLocaleString()}</span></td>
                  <td><span style={{ color: "rgb(148,163,184)", textTransform: "capitalize" }}>{p.method.replace("_", " ")}</span></td>
                  <td><span className={`badge-${p.status === "completed" ? "success" : p.status === "failed" ? "danger" : "warning"}`}>{p.status}</span></td>
                  <td><span style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{new Date(p.createdAt).toLocaleDateString()}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Subscribe Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>
                {selectedPlan ? `Subscribe to ${selectedPlan.charAt(0).toUpperCase() + selectedPlan.slice(1)}` : "Choose a Plan"}
              </h2>
              <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={20} /></button>
            </div>

            {!selectedPlan && (
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
                {(["silver", "gold", "diamond"] as const).map(p => (
                  <button key={p} onClick={() => setSelectedPlan(p)} style={{ padding: "14px 16px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(30,35,55,0.6)", cursor: "pointer", display: "flex", alignItems: "center", gap: 12 }}>
                    <span style={{ fontSize: 22 }}>{PLAN_DETAILS[p].icon}</span>
                    <div style={{ textAlign: "left", flex: 1 }}>
                      <div style={{ fontWeight: 700, color: "white", textTransform: "capitalize" }}>{p}</div>
                      <div style={{ fontSize: 13, color: "rgb(148,163,184)" }}>PKR {plans[p]?.monthlyPrice?.toLocaleString()}/month</div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {selectedPlan && plans[selectedPlan] && (
              <>
                <div style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 12, padding: 16, marginBottom: 20 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                    <span style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Plan</span>
                    <span style={{ color: "white", fontWeight: 600, textTransform: "capitalize" }}>{selectedPlan}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Amount</span>
                    <span style={{ color: "#22c55e", fontWeight: 800, fontSize: 18 }}>PKR {plans[selectedPlan].monthlyPrice.toLocaleString()}/mo</span>
                  </div>
                </div>

                <div style={{ marginBottom: 20 }}>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>Select Payment Method</label>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
                    {[
                      { value: "jazzcash", label: "JazzCash", emoji: "📱" },
                      { value: "easypaisa", label: "EasyPaisa", emoji: "💚" },
                      { value: "stripe", label: "Stripe", emoji: "💳" },
                    ].map(m => (
                      <button key={m.value} onClick={() => setPaymentMethod(m.value)} style={{ padding: "12px 8px", borderRadius: 10, border: "1px solid", cursor: "pointer", textAlign: "center", borderColor: paymentMethod === m.value ? "#6366f1" : "rgba(255,255,255,0.08)", background: paymentMethod === m.value ? "rgba(99,102,241,0.15)" : "rgba(30,35,55,0.6)" }}>
                        <div style={{ fontSize: 20, marginBottom: 4 }}>{m.emoji}</div>
                        <div style={{ fontSize: 11, fontWeight: 600, color: paymentMethod === m.value ? "#6366f1" : "rgb(148,163,184)" }}>{m.label}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={() => setShowModal(false)} style={{ flex: 1, padding: "11px", background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgb(148,163,184)", cursor: "pointer", fontSize: 14, fontWeight: 600 }}>Cancel</button>
                  <button onClick={subscribe} disabled={processing} className="btn-primary" style={{ flex: 2, padding: "11px" }}>
                    {processing ? "Processing..." : `Subscribe → PKR ${plans[selectedPlan].monthlyPrice.toLocaleString()}/mo`}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

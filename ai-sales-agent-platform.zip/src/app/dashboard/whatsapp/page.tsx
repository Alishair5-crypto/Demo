"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { MessageSquare, Send, Bot, User, Plus, Search, MoreVertical, Phone, Zap, RefreshCw } from "lucide-react";
import toast from "react-hot-toast";

interface Conversation {
  id: number;
  whatsappNumber: string;
  contactName: string | null;
  lastMessage: string | null;
  lastMessageAt: string | null;
  unreadCount: number;
  isAiManaged: boolean;
  leadStatus: string;
  customerFirstName: string | null;
  customerLastName: string | null;
}

interface Message {
  id: number;
  direction: string;
  content: string;
  isAiGenerated: boolean;
  sentAt: string;
  messageType: string;
}

export default function WhatsAppPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConv, setSelectedConv] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [showNewConvModal, setShowNewConvModal] = useState(false);
  const [newConvForm, setNewConvForm] = useState({ whatsappNumber: "", contactName: "" });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [convHistory, setConvHistory] = useState<{ role: string; content: string }[]>([]);

  const fetchConversations = useCallback(async () => {
    try {
      const res = await fetch("/api/conversations");
      const data = await res.json();
      setConversations(data.conversations || []);
    } catch {} finally { setLoadingConvs(false); }
  }, []);

  useEffect(() => { fetchConversations(); }, [fetchConversations]);

  const fetchMessages = useCallback(async (convId: number) => {
    try {
      const res = await fetch(`/api/conversations/${convId}/messages`);
      const data = await res.json();
      setMessages(data.messages || []);
      setConvHistory(
        (data.messages || []).slice(-10).map((m: Message) => ({ role: m.direction === "outbound" ? "assistant" : "user", content: m.content }))
      );
    } catch {}
  }, []);

  useEffect(() => {
    if (selectedConv) fetchMessages(selectedConv.id);
  }, [selectedConv, fetchMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (content: string, isAi = false) => {
    if (!selectedConv || !content.trim()) return;
    setSending(true);
    try {
      const res = await fetch(`/api/conversations/${selectedConv.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, direction: "outbound", isAiGenerated: isAi }),
      });
      const data = await res.json();
      if (res.ok) {
        setMessages(prev => [...prev, data.message]);
        setNewMessage("");
        fetchConversations();
      }
    } catch { toast.error("Failed to send"); }
    finally { setSending(false); }
  };

  const handleAiReply = async () => {
    if (!selectedConv || messages.length === 0) { toast.error("No messages to reply to"); return; }
    setAiLoading(true);
    try {
      const lastInbound = [...messages].reverse().find(m => m.direction === "inbound");
      const userMessage = lastInbound?.content || newMessage;
      if (!userMessage) { toast.error("No customer message to reply to"); setAiLoading(false); return; }

      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage, conversationHistory: convHistory, context: `WhatsApp conversation with ${selectedConv.contactName || selectedConv.whatsappNumber}` }),
      });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      await sendMessage(data.reply, true);
    } catch { toast.error("AI error"); }
    finally { setAiLoading(false); }
  };

  const createConversation = async () => {
    if (!newConvForm.whatsappNumber) { toast.error("WhatsApp number required"); return; }
    const res = await fetch("/api/conversations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newConvForm),
    });
    const data = await res.json();
    if (res.ok) {
      toast.success("Conversation started!");
      setShowNewConvModal(false);
      setNewConvForm({ whatsappNumber: "", contactName: "" });
      fetchConversations();
      setSelectedConv(data.conversation);
    }
  };

  const filteredConvs = conversations.filter(c =>
    (c.contactName || c.whatsappNumber).toLowerCase().includes(search.toLowerCase())
  );

  const contactName = (c: Conversation) =>
    c.contactName || (c.customerFirstName && c.customerLastName ? `${c.customerFirstName} ${c.customerLastName}` : c.whatsappNumber);

  return (
    <DashboardLayout title="WhatsApp">
      <div style={{ display: "flex", gap: 0, height: "calc(100vh - 120px)", borderRadius: 16, overflow: "hidden", border: "1px solid rgba(255,255,255,0.06)" }}>

        {/* Sidebar */}
        <div style={{ width: 320, borderRight: "1px solid rgba(255,255,255,0.06)", background: "rgba(22,27,42,0.8)", display: "flex", flexDirection: "column", flexShrink: 0 }}>
          <div style={{ padding: "16px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <MessageSquare size={18} style={{ color: "#22c55e" }} />
              <span style={{ fontSize: 15, fontWeight: 700, color: "white" }}>Conversations</span>
              <span style={{ marginLeft: "auto", background: "rgba(34,197,94,0.15)", color: "#22c55e", borderRadius: 20, padding: "2px 8px", fontSize: 11, fontWeight: 700 }}>{conversations.length}</span>
              <button onClick={() => setShowNewConvModal(true)} style={{ background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 8, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#22c55e" }}><Plus size={14} /></button>
            </div>
            <div style={{ position: "relative" }}>
              <Search size={13} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
              <input className="input-field" placeholder="Search conversations..." value={search} onChange={e => setSearch(e.target.value)} style={{ paddingLeft: 32, fontSize: 12, height: 34 }} />
            </div>
          </div>

          <div style={{ flex: 1, overflowY: "auto" }}>
            {loadingConvs ? (
              Array(5).fill(0).map((_, i) => (
                <div key={i} style={{ padding: "14px 16px", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <div style={{ display: "flex", gap: 10 }}>
                    <div className="skeleton" style={{ width: 40, height: 40, borderRadius: "50%", flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div className="skeleton" style={{ height: 13, width: "60%", marginBottom: 6 }} />
                      <div className="skeleton" style={{ height: 11, width: "80%" }} />
                    </div>
                  </div>
                </div>
              ))
            ) : filteredConvs.length === 0 ? (
              <div style={{ padding: "40px 20px", textAlign: "center", color: "rgb(100,116,139)" }}>
                <MessageSquare size={32} style={{ margin: "0 auto 10px", opacity: 0.3 }} />
                <div style={{ fontSize: 13 }}>No conversations yet</div>
                <button onClick={() => setShowNewConvModal(true)} style={{ marginTop: 12, background: "rgba(34,197,94,0.15)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 8, padding: "7px 14px", color: "#22c55e", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>Start conversation</button>
              </div>
            ) : (
              filteredConvs.map(c => (
                <div
                  key={c.id}
                  onClick={() => setSelectedConv(c)}
                  style={{ padding: "13px 16px", borderBottom: "1px solid rgba(255,255,255,0.04)", cursor: "pointer", background: selectedConv?.id === c.id ? "rgba(34,197,94,0.08)" : "transparent", borderLeft: selectedConv?.id === c.id ? "3px solid #22c55e" : "3px solid transparent", transition: "all 0.15s" }}
                >
                  <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: c.isAiManaged ? "linear-gradient(135deg, #22c55e, #16a34a)" : "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>
                      {c.isAiManaged ? "🤖" : "👤"}
                    </div>
                    <div style={{ flex: 1, overflow: "hidden" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: "white", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{contactName(c)}</span>
                        {c.lastMessageAt && <span style={{ fontSize: 10, color: "rgb(100,116,139)", flexShrink: 0 }}>{new Date(c.lastMessageAt).toLocaleDateString()}</span>}
                      </div>
                      <div style={{ fontSize: 12, color: "rgb(100,116,139)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginTop: 2 }}>{c.lastMessage || "No messages"}</div>
                    </div>
                    {c.unreadCount > 0 && (
                      <div style={{ background: "#22c55e", color: "white", borderRadius: "50%", width: 18, height: 18, fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{c.unreadCount}</div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chat Area */}
        {selectedConv ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", background: "rgba(15,17,26,0.9)" }}>
            {/* Chat Header */}
            <div style={{ padding: "14px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", gap: 12, background: "rgba(22,27,42,0.5)" }}>
              <div style={{ width: 40, height: 40, borderRadius: "50%", background: "linear-gradient(135deg, #22c55e, #16a34a)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>
                {selectedConv.isAiManaged ? "🤖" : "👤"}
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>{contactName(selectedConv)}</div>
                <div style={{ fontSize: 11, color: "rgb(100,116,139)", display: "flex", alignItems: "center", gap: 4 }}>
                  <Phone size={10} /> {selectedConv.whatsappNumber}
                </div>
              </div>
              <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
                {selectedConv.isAiManaged && (
                  <div style={{ display: "flex", alignItems: "center", gap: 5, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 8, padding: "4px 10px" }}>
                    <div className="pulse-dot" style={{ width: 6, height: 6, background: "#22c55e", color: "#22c55e" }} />
                    <span style={{ fontSize: 11, color: "#22c55e", fontWeight: 600 }}>AI Active</span>
                  </div>
                )}
                <button onClick={() => fetchMessages(selectedConv.id)} style={{ background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "rgb(148,163,184)" }}><RefreshCw size={14} /></button>
              </div>
            </div>

            {/* Messages */}
            <div style={{ flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: 12 }}>
              {messages.length === 0 ? (
                <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "rgb(100,116,139)", textAlign: "center" }}>
                  <MessageSquare size={48} style={{ marginBottom: 16, opacity: 0.2 }} />
                  <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 6 }}>No messages yet</div>
                  <div style={{ fontSize: 13 }}>Start the conversation below</div>
                </div>
              ) : (
                messages.map(m => (
                  <div key={m.id} style={{ display: "flex", flexDirection: m.direction === "outbound" ? "row-reverse" : "row", alignItems: "flex-end", gap: 8 }}>
                    {m.direction === "inbound" && (
                      <div style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(30,35,55,0.8)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>👤</div>
                    )}
                    {m.direction === "outbound" && m.isAiGenerated && (
                      <div style={{ width: 28, height: 28, borderRadius: "50%", background: "rgba(245,158,11,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>🤖</div>
                    )}
                    <div>
                      <div className={m.direction === "outbound" ? "chat-bubble-out" : "chat-bubble-in"}>
                        {m.content}
                      </div>
                      <div style={{ fontSize: 10, color: "rgb(100,116,139)", marginTop: 4, textAlign: m.direction === "outbound" ? "right" : "left", display: "flex", alignItems: "center", gap: 4, justifyContent: m.direction === "outbound" ? "flex-end" : "flex-start" }}>
                        {m.isAiGenerated && <span style={{ background: "rgba(245,158,11,0.1)", color: "#f59e0b", borderRadius: 4, padding: "1px 5px", fontSize: 9, fontWeight: 600 }}>AI</span>}
                        {new Date(m.sentAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div style={{ padding: "14px 20px", borderTop: "1px solid rgba(255,255,255,0.06)", background: "rgba(22,27,42,0.5)" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
                <textarea
                  className="input-field"
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(newMessage); } }}
                  rows={1}
                  style={{ flex: 1, resize: "none", fontSize: 13 }}
                />
                <button
                  onClick={handleAiReply}
                  disabled={aiLoading}
                  title="Generate AI reply"
                  style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 10, width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#f59e0b", flexShrink: 0 }}
                >
                  {aiLoading ? <RefreshCw size={16} style={{ animation: "spin 1s linear infinite" }} /> : <Bot size={16} />}
                </button>
                <button
                  onClick={() => sendMessage(newMessage)}
                  disabled={sending || !newMessage.trim()}
                  style={{ background: "linear-gradient(135deg, #22c55e, #16a34a)", border: "none", borderRadius: 10, width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "white", flexShrink: 0, opacity: (!newMessage.trim() || sending) ? 0.6 : 1 }}
                >
                  <Send size={16} />
                </button>
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button onClick={() => { setNewMessage("Hello! How can I help you today?"); }} style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 7, padding: "4px 10px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 11 }}>👋 Greeting</button>
                <button onClick={() => { setNewMessage("Thank you for your order! It will be delivered within 2-3 business days."); }} style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 7, padding: "4px 10px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 11 }}>📦 Order Update</button>
                <button onClick={() => { setNewMessage("We have some amazing offers for you today! Would you like to know more?"); }} style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 7, padding: "4px 10px", color: "rgb(148,163,184)", cursor: "pointer", fontSize: 11 }}>🎯 Offer</button>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "rgb(100,116,139)", background: "rgba(15,17,26,0.6)" }}>
            <MessageSquare size={56} style={{ marginBottom: 16, opacity: 0.15 }} />
            <div style={{ fontSize: 18, fontWeight: 600, color: "white", marginBottom: 6 }}>Select a conversation</div>
            <div style={{ fontSize: 13, marginBottom: 20 }}>Or start a new conversation with a customer</div>
            <button onClick={() => setShowNewConvModal(true)} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <Plus size={15} /> New Conversation
            </button>
          </div>
        )}
      </div>

      {/* New Conversation Modal */}
      {showNewConvModal && (
        <div className="modal-overlay" onClick={() => setShowNewConvModal(false)}>
          <div className="modal-content" style={{ maxWidth: 440 }} onClick={e => e.stopPropagation()}>
            <h2 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 20 }}>Start New Conversation</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>WhatsApp Number *</label>
                <input className="input-field" placeholder="+92 300 0000000" value={newConvForm.whatsappNumber} onChange={e => setNewConvForm({ ...newConvForm, whatsappNumber: e.target.value })} />
              </div>
              <div>
                <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Contact Name</label>
                <input className="input-field" placeholder="Customer name" value={newConvForm.contactName} onChange={e => setNewConvForm({ ...newConvForm, contactName: e.target.value })} />
              </div>
              <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                <button onClick={() => setShowNewConvModal(false)} style={{ flex: 1, padding: "11px", background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgb(148,163,184)", cursor: "pointer", fontSize: 14, fontWeight: 600 }}>Cancel</button>
                <button onClick={createConversation} className="btn-primary" style={{ flex: 2, padding: "11px" }}>Start Conversation</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

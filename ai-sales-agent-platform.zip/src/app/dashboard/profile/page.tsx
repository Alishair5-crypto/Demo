"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { User, Camera, Mail, Phone, Building, Globe, Clock, Shield, Save } from "lucide-react";
import toast from "react-hot-toast";
import { useStore } from "@/store/useStore";

interface Profile {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  companyName: string | null;
  companyLogo: string | null;
  phone: string | null;
  timezone: string | null;
  language: string | null;
  theme: string | null;
  createdAt: string;
  lastLogin: string | null;
}

const TIMEZONES = ["UTC", "Asia/Karachi", "Asia/Dubai", "Europe/London", "America/New_York", "America/Los_Angeles", "Asia/Tokyo", "Asia/Singapore"];
const LANGUAGES = [{ value: "en", label: "English" }, { value: "ur", label: "Urdu" }, { value: "ar", label: "Arabic" }];

export default function ProfilePage() {
  const { setUser } = useStore();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const [form, setForm] = useState({ firstName: "", lastName: "", companyName: "", phone: "", timezone: "Asia/Karachi", language: "en", theme: "dark" });
  const [passwordForm, setPasswordForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });

  useEffect(() => {
    fetch("/api/profile")
      .then(r => r.json())
      .then(data => {
        setProfile(data.user);
        setForm({
          firstName: data.user.firstName || "",
          lastName: data.user.lastName || "",
          companyName: data.user.companyName || "",
          phone: data.user.phone || "",
          timezone: data.user.timezone || "Asia/Karachi",
          language: data.user.language || "en",
          theme: data.user.theme || "dark",
        });
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      setProfile(data.user);
      setUser({ id: data.user.id, email: data.user.email, firstName: data.user.firstName, lastName: data.user.lastName, role: data.user.role, companyName: data.user.companyName, companyLogo: data.user.companyLogo, phone: data.user.phone });
      toast.success("Profile updated!");
    } catch { toast.error("Failed to save"); }
    finally { setSaving(false); }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.newPassword !== passwordForm.confirmPassword) { toast.error("Passwords don't match"); return; }
    if (passwordForm.newPassword.length < 8) { toast.error("Password must be at least 8 characters"); return; }
    setSaving(true);
    try {
      const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPassword: passwordForm.currentPassword, newPassword: passwordForm.newPassword }) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success("Password changed successfully!");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch { toast.error("Failed to change password"); }
    finally { setSaving(false); }
  };

  if (loading) return (
    <DashboardLayout title="Profile">
      <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 20 }}>
        {[1, 2].map(i => <div key={i} className="skeleton" style={{ height: 400, borderRadius: 16 }} />)}
      </div>
    </DashboardLayout>
  );

  const initials = profile ? `${profile.firstName[0]}${profile.lastName[0]}` : "?";

  return (
    <DashboardLayout title="Profile">
      <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 20 }}>
        {/* Left: Avatar & Info */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="glass-card" style={{ padding: 28, textAlign: "center" }}>
            <div style={{ position: "relative", display: "inline-block", marginBottom: 16 }}>
              <div style={{ width: 88, height: 88, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 800, color: "white", margin: "0 auto" }}>
                {profile?.companyLogo ? <img src={profile.companyLogo} alt="logo" style={{ width: "100%", height: "100%", borderRadius: "50%", objectFit: "cover" }} /> : initials}
              </div>
              <button style={{ position: "absolute", bottom: 0, right: 0, width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "2px solid rgb(22,27,42)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "white" }}>
                <Camera size={12} />
              </button>
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 4 }}>{profile?.firstName} {profile?.lastName}</h3>
            <p style={{ fontSize: 13, color: "rgb(148,163,184)", marginBottom: 8 }}>{profile?.companyName || "No company set"}</p>
            <span style={{ background: "rgba(99,102,241,0.15)", color: "#6366f1", borderRadius: 20, padding: "4px 14px", fontSize: 12, fontWeight: 700, textTransform: "capitalize" }}>{profile?.role}</span>
          </div>

          <div className="glass-card" style={{ padding: 20 }}>
            <h4 style={{ fontSize: 12, fontWeight: 700, color: "rgb(100,116,139)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 14 }}>Account Info</h4>
            {[
              { icon: <Mail size={14} />, label: "Email", value: profile?.email },
              { icon: <Phone size={14} />, label: "Phone", value: profile?.phone || "—" },
              { icon: <Clock size={14} />, label: "Member Since", value: profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : "—" },
              { icon: <Shield size={14} />, label: "Last Login", value: profile?.lastLogin ? new Date(profile.lastLogin).toLocaleDateString() : "—" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: i < 3 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
                <span style={{ color: "#6366f1" }}>{item.icon}</span>
                <div>
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginBottom: 1 }}>{item.label}</div>
                  <div style={{ fontSize: 13, color: "white", fontWeight: 500 }}>{item.value}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Forms */}
        <div>
          {/* Tabs */}
          <div style={{ display: "flex", gap: 4, background: "rgba(30,35,55,0.6)", borderRadius: 12, padding: 4, marginBottom: 20, width: "fit-content" }}>
            {["profile", "password"].map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab)} style={{ padding: "8px 20px", borderRadius: 10, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, background: activeTab === tab ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "transparent", color: activeTab === tab ? "white" : "rgb(148,163,184)", textTransform: "capitalize" }}>
                {tab === "profile" ? "Edit Profile" : "Change Password"}
              </button>
            ))}
          </div>

          {activeTab === "profile" && (
            <div className="glass-card" style={{ padding: 28 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 20, display: "flex", alignItems: "center", gap: 8 }}>
                <User size={16} style={{ color: "#6366f1" }} /> Personal Information
              </h3>
              <form onSubmit={saveProfile}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>First Name</label>
                    <input className="input-field" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Last Name</label>
                    <input className="input-field" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required />
                  </div>
                  <div style={{ gridColumn: "1/-1" }}>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Company Name</label>
                    <div style={{ position: "relative" }}>
                      <Building size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
                      <input className="input-field" value={form.companyName} onChange={e => setForm({ ...form, companyName: e.target.value })} style={{ paddingLeft: 36 }} placeholder="Your Company Name" />
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Phone</label>
                    <div style={{ position: "relative" }}>
                      <Phone size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
                      <input className="input-field" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} style={{ paddingLeft: 36 }} placeholder="+92 300 0000000" />
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Timezone</label>
                    <div style={{ position: "relative" }}>
                      <Clock size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
                      <select className="input-field" value={form.timezone} onChange={e => setForm({ ...form, timezone: e.target.value })} style={{ paddingLeft: 36 }}>
                        {TIMEZONES.map(tz => <option key={tz} value={tz}>{tz}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Language</label>
                    <div style={{ position: "relative" }}>
                      <Globe size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
                      <select className="input-field" value={form.language} onChange={e => setForm({ ...form, language: e.target.value })} style={{ paddingLeft: 36 }}>
                        {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Theme</label>
                    <select className="input-field" value={form.theme} onChange={e => setForm({ ...form, theme: e.target.value })}>
                      <option value="dark">Dark Mode</option>
                      <option value="light">Light Mode</option>
                    </select>
                  </div>
                </div>
                <div style={{ marginTop: 20 }}>
                  <button type="submit" disabled={saving} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 8, padding: "11px 24px" }}>
                    <Save size={16} /> {saving ? "Saving..." : "Save Changes"}
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === "password" && (
            <div className="glass-card" style={{ padding: 28 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 20, display: "flex", alignItems: "center", gap: 8 }}>
                <Shield size={16} style={{ color: "#6366f1" }} /> Change Password
              </h3>
              <form onSubmit={changePassword}>
                <div style={{ display: "flex", flexDirection: "column", gap: 16, maxWidth: 400 }}>
                  {[
                    { label: "Current Password", field: "currentPassword" as const },
                    { label: "New Password", field: "newPassword" as const },
                    { label: "Confirm New Password", field: "confirmPassword" as const },
                  ].map(item => (
                    <div key={item.field}>
                      <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>{item.label}</label>
                      <input
                        className="input-field"
                        type="password"
                        value={passwordForm[item.field]}
                        onChange={e => setPasswordForm({ ...passwordForm, [item.field]: e.target.value })}
                        required
                        minLength={item.field !== "currentPassword" ? 8 : 1}
                        placeholder="••••••••"
                      />
                    </div>
                  ))}
                  <div style={{ padding: 14, background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 10 }}>
                    <p style={{ fontSize: 12, color: "#3b82f6", lineHeight: 1.6 }}>
                      🔒 Password must be at least 8 characters long. Use a mix of letters, numbers, and symbols for security.
                    </p>
                  </div>
                  <button type="submit" disabled={saving} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 8, padding: "11px 24px", width: "fit-content" }}>
                    <Shield size={16} /> {saving ? "Changing..." : "Change Password"}
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

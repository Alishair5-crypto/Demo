"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { BarChart3, TrendingUp, Users, Package, Zap } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, FunnelChart, Funnel, LabelList
} from "recharts";
import { formatCurrency } from "@/lib/utils";

interface AnalyticsData {
  revenueData: { date: string; revenue: number; orders: number }[];
  leadStatusData: { status: string; count: number }[];
  orderStatusData: { status: string; count: number; total: string }[];
  topProducts: { name: string; quantity: number; revenue: number }[];
  conversionFunnel: { stage: string; count: number }[];
}

const COLORS = ["#6366f1", "#8b5cf6", "#ec4899", "#22c55e", "#f59e0b", "#3b82f6", "#14b8a6"];
const PERIODS = [{ label: "7 Days", value: "7d" }, { label: "30 Days", value: "30d" }, { label: "90 Days", value: "90d" }, { label: "1 Year", value: "1y" }];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color: string }>; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: "rgba(22,27,42,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "10px 14px" }}>
        <p style={{ color: "rgb(148,163,184)", fontSize: 12, marginBottom: 6 }}>{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color, fontSize: 13, fontWeight: 700 }}>{p.name === "revenue" ? formatCurrency(p.value) : p.value}</p>
        ))}
      </div>
    );
  }
  return null;
};

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [period, setPeriod] = useState("30d");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/analytics?period=${period}`)
      .then(r => r.json())
      .then(d => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [period]);

  const totalRevenue = data?.revenueData?.reduce((s, d) => s + d.revenue, 0) || 0;
  const totalOrders = data?.revenueData?.reduce((s, d) => s + d.orders, 0) || 0;
  const totalLeads = data?.leadStatusData?.reduce((s, d) => s + d.count, 0) || 0;

  return (
    <DashboardLayout title="Analytics">
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <BarChart3 size={24} style={{ color: "#3b82f6" }} /> Analytics
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Track your business performance</p>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {PERIODS.map(p => (
            <button key={p.value} onClick={() => setPeriod(p.value)} style={{ padding: "7px 14px", borderRadius: 8, border: "1px solid", fontSize: 12, fontWeight: 600, cursor: "pointer", borderColor: period === p.value ? "#6366f1" : "rgba(255,255,255,0.08)", background: period === p.value ? "rgba(99,102,241,0.15)" : "rgba(30,35,55,0.6)", color: period === p.value ? "#6366f1" : "rgb(148,163,184)" }}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Top Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Revenue", value: formatCurrency(totalRevenue), icon: <TrendingUp size={18} />, color: "#6366f1", bg: "rgba(99,102,241,0.1)" },
          { label: "Total Orders", value: totalOrders.toLocaleString(), icon: <Package size={18} />, color: "#ec4899", bg: "rgba(236,72,153,0.1)" },
          { label: "Total Leads", value: totalLeads.toLocaleString(), icon: <Users size={18} />, color: "#8b5cf6", bg: "rgba(139,92,246,0.1)" },
          { label: "Avg Order Value", value: totalOrders > 0 ? formatCurrency(totalRevenue / totalOrders) : "—", icon: <Zap size={18} />, color: "#22c55e", bg: "rgba(34,197,94,0.1)" },
        ].map((s, i) => (
          <div key={i} className="stat-card">
            <div style={{ width: 40, height: 40, borderRadius: 10, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", color: s.color, marginBottom: 12 }}>{s.icon}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "white", marginBottom: 2 }}>{loading ? <div className="skeleton" style={{ height: 26, width: 80 }} /> : s.value}</div>
            <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Revenue Chart */}
      <div className="glass-card" style={{ padding: 24, marginBottom: 20 }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Revenue & Orders Trend</h3>
        <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 20 }}>Revenue and order volume over time</p>
        {loading ? (
          <div className="skeleton" style={{ height: 250 }} />
        ) : (
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={data?.revenueData || []}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="ordGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} tickFormatter={v => `₨${(v/1000).toFixed(0)}k`} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area yAxisId="left" type="monotone" dataKey="revenue" name="revenue" stroke="#6366f1" strokeWidth={2.5} fill="url(#revGrad)" dot={false} />
              <Area yAxisId="right" type="monotone" dataKey="orders" name="orders" stroke="#22c55e" strokeWidth={2} fill="url(#ordGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
        {/* Lead Status */}
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Lead Status Distribution</h3>
          <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 20 }}>How your leads are progressing</p>
          {loading ? <div className="skeleton" style={{ height: 200 }} /> : (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={data?.leadStatusData || []} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={80} innerRadius={50}>
                  {(data?.leadStatusData || []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => [v, "Count"]} />
                <Legend formatter={(v) => <span style={{ fontSize: 12, color: "rgb(148,163,184)" }}>{v}</span>} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Orders by Status */}
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Orders by Status</h3>
          <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 20 }}>Order status breakdown</p>
          {loading ? <div className="skeleton" style={{ height: 200 }} /> : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={data?.orderStatusData || []} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="status" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} width={80} />
                <Tooltip />
                <Bar dataKey="count" radius={[0, 6, 6, 0]} fill="#8b5cf6">
                  {(data?.orderStatusData || []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Top Products & Conversion Funnel */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Top Products */}
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Top Products</h3>
          <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 20 }}>Best performing products by revenue</p>
          {loading ? (
            Array(5).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 40, marginBottom: 8 }} />)
          ) : (data?.topProducts || []).length === 0 ? (
            <div style={{ textAlign: "center", padding: "30px", color: "rgb(100,116,139)", fontSize: 13 }}>No product data yet</div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {(data?.topProducts || []).slice(0, 5).map((p, i) => {
                const maxRev = (data?.topProducts?.[0]?.revenue ?? 1) || 1;
                const pct = (p.revenue / maxRev) * 100;
                return (
                  <div key={i}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: 13, color: "white", fontWeight: 500 }}>{p.name}</span>
                      <span style={{ fontSize: 13, color: "#22c55e", fontWeight: 700 }}>{formatCurrency(p.revenue)}</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }} />
                    </div>
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 2 }}>{p.quantity} units sold</div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Conversion Funnel */}
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Conversion Funnel</h3>
          <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 20 }}>Lead to customer journey</p>
          {loading ? (
            Array(4).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 50, marginBottom: 8, borderRadius: 8 }} />)
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {(data?.conversionFunnel || []).map((stage, i) => {
                const maxCount = (data?.conversionFunnel?.[0]?.count ?? 1) || 1;
                const pct = maxCount > 0 ? (stage.count / maxCount) * 100 : 0;
                return (
                  <div key={i} style={{ background: "rgba(30,35,55,0.5)", borderRadius: 10, padding: "12px 16px", position: "relative", overflow: "hidden" }}>
                    <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: `${pct}%`, background: `rgba(${i === 0 ? "99,102,241" : i === 1 ? "139,92,246" : i === 2 ? "34,197,94" : "245,158,11"},0.15)`, transition: "width 0.5s ease" }} />
                    <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontSize: 13, color: "white", fontWeight: 600 }}>{stage.stage}</span>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontSize: 18, fontWeight: 800, color: COLORS[i] }}>{stage.count}</span>
                        <span style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{pct.toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

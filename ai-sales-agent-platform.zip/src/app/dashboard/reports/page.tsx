"use client";

import { useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { FileText, Download, Calendar, TrendingUp, Package, Users, DollarSign, BarChart3 } from "lucide-react";
import toast from "react-hot-toast";

const REPORT_TYPES = [
  { id: "daily", label: "Daily Report", icon: "📅", desc: "Today's sales, orders, and customer activity", color: "#6366f1" },
  { id: "weekly", label: "Weekly Report", icon: "📊", desc: "Last 7 days performance summary", color: "#8b5cf6" },
  { id: "monthly", label: "Monthly Report", icon: "📈", desc: "Monthly revenue, orders, and growth metrics", color: "#ec4899" },
  { id: "yearly", label: "Yearly Report", icon: "🗓️", desc: "Annual business performance and trends", color: "#22c55e" },
  { id: "customers", label: "Customer Report", icon: "👥", desc: "Customer acquisition, retention, and lifetime value", color: "#f59e0b" },
  { id: "orders", label: "Orders Report", icon: "📦", desc: "Order status, fulfillment rates, and revenue", color: "#3b82f6" },
];

interface ReportData {
  title: string;
  period: string;
  totalRevenue: number;
  totalOrders: number;
  newCustomers: number;
  conversionRate: number;
  topProducts: { name: string; revenue: number; orders: number }[];
  ordersByStatus: { status: string; count: number }[];
}

export default function ReportsPage() {
  const [selectedReport, setSelectedReport] = useState("daily");
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const generateReport = async () => {
    setLoading(true);
    setGenerated(false);
    try {
      const periodMap: Record<string, string> = { daily: "7d", weekly: "7d", monthly: "30d", yearly: "1y", customers: "30d", orders: "30d" };
      const res = await fetch(`/api/analytics?period=${periodMap[selectedReport]}`);
      const data = await res.json();

      const totalRev = (data.revenueData || []).reduce((s: number, d: { revenue: number }) => s + d.revenue, 0);
      const totalOrders = (data.revenueData || []).reduce((s: number, d: { orders: number }) => s + d.orders, 0);
      const funnel = data.conversionFunnel || [];
      const converted = funnel.find((f: { stage: string; count: number }) => f.stage === "Converted")?.count || 0;
      const qualified = funnel.find((f: { stage: string; count: number }) => f.stage === "Qualified")?.count || 1;

      setReportData({
        title: REPORT_TYPES.find(r => r.id === selectedReport)?.label || "Report",
        period: new Date().toLocaleDateString("default", { year: "numeric", month: "long", day: "numeric" }),
        totalRevenue: totalRev,
        totalOrders,
        newCustomers: (data.leadStatusData || []).find((s: { status: string; count: number }) => s.status === "new")?.count || 0,
        conversionRate: qualified > 0 ? Math.round((converted / qualified) * 100) : 0,
        topProducts: data.topProducts || [],
        ordersByStatus: data.orderStatusData || [],
      });
      setGenerated(true);
      toast.success("Report generated!");
    } catch { toast.error("Failed to generate report"); }
    finally { setLoading(false); }
  };

  const downloadPDF = () => {
    toast.success("PDF export feature ready for production integration");
  };

  const downloadExcel = () => {
    if (!reportData) return;
    const csvRows = [
      ["Report", reportData.title],
      ["Period", reportData.period],
      [""],
      ["Metric", "Value"],
      ["Total Revenue", `PKR ${reportData.totalRevenue.toLocaleString()}`],
      ["Total Orders", reportData.totalOrders],
      ["New Customers", reportData.newCustomers],
      ["Conversion Rate", `${reportData.conversionRate}%`],
      [""],
      ["Top Products"],
      ["Product Name", "Revenue", "Orders"],
      ...(reportData.topProducts || []).map(p => [p.name, `PKR ${p.revenue.toLocaleString()}`, p.orders]),
    ];
    const csvContent = csvRows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedReport}-report-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Excel/CSV downloaded!");
  };

  return (
    <DashboardLayout title="Reports">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <FileText size={24} style={{ color: "#14b8a6" }} /> Reports
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Generate and export business reports</p>
        </div>
        {generated && (
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={downloadExcel} style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 10, padding: "9px 16px", color: "#22c55e", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
              <Download size={15} /> Excel/CSV
            </button>
            <button onClick={downloadPDF} style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 10, padding: "9px 16px", color: "#ef4444", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
              <Download size={15} /> PDF
            </button>
          </div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 20 }}>
        {/* Report Types */}
        <div>
          <div className="glass-card" style={{ padding: 16 }}>
            <h3 style={{ fontSize: 13, fontWeight: 700, color: "rgb(148,163,184)", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 12 }}>Report Type</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {REPORT_TYPES.map(r => (
                <button
                  key={r.id}
                  onClick={() => { setSelectedReport(r.id); setGenerated(false); }}
                  style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 10, border: "1px solid", cursor: "pointer", textAlign: "left", transition: "all 0.2s", borderColor: selectedReport === r.id ? r.color : "rgba(255,255,255,0.06)", background: selectedReport === r.id ? `rgba(${r.color === "#6366f1" ? "99,102,241" : r.color === "#8b5cf6" ? "139,92,246" : r.color === "#ec4899" ? "236,72,153" : r.color === "#22c55e" ? "34,197,94" : r.color === "#f59e0b" ? "245,158,11" : "59,130,246"},0.1)` : "rgba(30,35,55,0.4)" }}
                >
                  <span style={{ fontSize: 20 }}>{r.icon}</span>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "white", marginBottom: 2 }}>{r.label}</div>
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{r.desc}</div>
                  </div>
                </button>
              ))}
            </div>
            <button
              onClick={generateReport}
              disabled={loading}
              className="btn-primary"
              style={{ width: "100%", marginTop: 16, padding: "12px" }}
            >
              {loading ? "Generating..." : "🚀 Generate Report"}
            </button>
          </div>
        </div>

        {/* Report Content */}
        <div>
          {!generated ? (
            <div className="glass-card" style={{ padding: 60, textAlign: "center" }}>
              <div style={{ fontSize: 60, marginBottom: 16 }}>📊</div>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 8 }}>Select a report type and generate</h3>
              <p style={{ fontSize: 13, color: "rgb(100,116,139)", maxWidth: 400, margin: "0 auto" }}>
                Choose from daily, weekly, monthly, or yearly reports. Includes revenue, orders, customers, and conversion metrics.
              </p>
            </div>
          ) : reportData ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {/* Report Header */}
              <div className="glass-card" style={{ padding: 24 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div>
                    <h2 style={{ fontSize: 22, fontWeight: 800, color: "white", marginBottom: 4 }}>{reportData.title}</h2>
                    <p style={{ fontSize: 13, color: "rgb(148,163,184)", display: "flex", alignItems: "center", gap: 6 }}>
                      <Calendar size={13} /> Generated on {reportData.period}
                    </p>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 8, padding: "6px 12px" }}>
                    <div className="pulse-dot" style={{ width: 6, height: 6, background: "#22c55e", color: "#22c55e" }} />
                    <span style={{ fontSize: 12, color: "#22c55e", fontWeight: 600 }}>Live Data</span>
                  </div>
                </div>
              </div>

              {/* Key Metrics */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
                {[
                  { label: "Total Revenue", value: `PKR ${reportData.totalRevenue.toLocaleString()}`, icon: <DollarSign size={18} />, color: "#6366f1", bg: "rgba(99,102,241,0.1)" },
                  { label: "Total Orders", value: reportData.totalOrders.toString(), icon: <Package size={18} />, color: "#ec4899", bg: "rgba(236,72,153,0.1)" },
                  { label: "New Customers", value: reportData.newCustomers.toString(), icon: <Users size={18} />, color: "#8b5cf6", bg: "rgba(139,92,246,0.1)" },
                  { label: "Conversion Rate", value: `${reportData.conversionRate}%`, icon: <TrendingUp size={18} />, color: "#22c55e", bg: "rgba(34,197,94,0.1)" },
                ].map((m, i) => (
                  <div key={i} className="stat-card" style={{ padding: 18 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 10, background: m.bg, display: "flex", alignItems: "center", justifyContent: "center", color: m.color, marginBottom: 10 }}>{m.icon}</div>
                    <div style={{ fontSize: 20, fontWeight: 800, color: "white", marginBottom: 2 }}>{m.value}</div>
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{m.label}</div>
                  </div>
                ))}
              </div>

              {/* Top Products */}
              <div className="glass-card" style={{ padding: 24 }}>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
                  <BarChart3 size={16} style={{ color: "#8b5cf6" }} /> Top Products
                </h3>
                {(reportData.topProducts || []).length === 0 ? (
                  <div style={{ textAlign: "center", padding: "20px", color: "rgb(100,116,139)", fontSize: 13 }}>No product data for this period</div>
                ) : (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th>Orders</th>
                        <th>Revenue</th>
                        <th>Share</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reportData.topProducts.slice(0, 8).map((p, i) => {
                        const share = reportData.totalRevenue > 0 ? (p.revenue / reportData.totalRevenue * 100).toFixed(1) : "0";
                        return (
                          <tr key={i}>
                            <td><span style={{ fontWeight: 600, color: "white" }}>{p.name}</span></td>
                            <td><span style={{ color: "rgb(148,163,184)" }}>{p.orders}</span></td>
                            <td><span style={{ color: "#22c55e", fontWeight: 700 }}>PKR {p.revenue.toLocaleString()}</span></td>
                            <td>
                              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <div className="progress-bar" style={{ flex: 1 }}>
                                  <div className="progress-fill" style={{ width: `${share}%` }} />
                                </div>
                                <span style={{ fontSize: 12, color: "rgb(100,116,139)", minWidth: 36 }}>{share}%</span>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Orders by Status */}
              <div className="glass-card" style={{ padding: 24 }}>
                <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
                  <Package size={16} style={{ color: "#ec4899" }} /> Orders Summary
                </h3>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
                  {(reportData.ordersByStatus || []).map((s, i) => (
                    <div key={i} style={{ background: "rgba(30,35,55,0.5)", borderRadius: 10, padding: "14px 16px", textAlign: "center" }}>
                      <div style={{ fontSize: 24, fontWeight: 800, color: ["#6366f1", "#f59e0b", "#22c55e", "#ef4444", "#8b5cf6", "#3b82f6"][i % 6], marginBottom: 4 }}>{s.count}</div>
                      <div style={{ fontSize: 12, color: "rgb(100,116,139)", textTransform: "capitalize" }}>{s.status}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </DashboardLayout>
  );
}

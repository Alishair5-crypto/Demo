"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { CreditCard, Download, Filter, DollarSign, TrendingUp, CheckCircle, Clock } from "lucide-react";

interface Payment {
  id: number;
  amount: string;
  currency: string;
  method: string;
  status: string;
  transactionId: string | null;
  invoiceNumber: string | null;
  paidAt: string | null;
  createdAt: string;
}

export default function PaymentsPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/subscriptions")
      .then(r => r.json())
      .then(data => {
        setPayments(data.paymentHistory || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const totalPaid = payments.filter(p => p.status === "completed").reduce((s, p) => s + parseFloat(p.amount), 0);
  const pendingAmount = payments.filter(p => p.status === "pending").reduce((s, p) => s + parseFloat(p.amount), 0);

  const METHOD_ICONS: Record<string, string> = { jazzcash: "📱", easypaisa: "💚", stripe: "💳", bank_transfer: "🏦" };
  const STATUS_COLORS: Record<string, string> = { completed: "success", pending: "warning", failed: "danger", refunded: "info" };

  return (
    <DashboardLayout title="Payments">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <CreditCard size={24} style={{ color: "#22c55e" }} /> Payments
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Payment history and invoices</p>
        </div>
        <button style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, padding: "9px 16px", color: "#22c55e", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
          <Download size={15} /> Export
        </button>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Paid", value: `PKR ${totalPaid.toLocaleString()}`, icon: <CheckCircle size={18} />, color: "#22c55e", bg: "rgba(34,197,94,0.1)" },
          { label: "Pending Amount", value: `PKR ${pendingAmount.toLocaleString()}`, icon: <Clock size={18} />, color: "#f59e0b", bg: "rgba(245,158,11,0.1)" },
          { label: "Total Transactions", value: payments.length.toString(), icon: <CreditCard size={18} />, color: "#6366f1", bg: "rgba(99,102,241,0.1)" },
          { label: "Successful Payments", value: payments.filter(p => p.status === "completed").length.toString(), icon: <TrendingUp size={18} />, color: "#8b5cf6", bg: "rgba(139,92,246,0.1)" },
        ].map((s, i) => (
          <div key={i} className="stat-card">
            <div style={{ width: 40, height: 40, borderRadius: 10, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", color: s.color, marginBottom: 12 }}>{s.icon}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "white", marginBottom: 2 }}>{s.value}</div>
            <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Payment Methods Accepted */}
      <div className="glass-card" style={{ padding: 20, marginBottom: 24 }}>
        <h3 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 14 }}>Accepted Payment Methods</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12 }}>
          {[
            { name: "JazzCash", emoji: "📱", desc: "Mobile wallet payments", color: "#ef4444", status: "Active" },
            { name: "EasyPaisa", emoji: "💚", desc: "Telenor mobile payments", color: "#22c55e", status: "Active" },
            { name: "Stripe", emoji: "💳", desc: "International card payments", color: "#6366f1", status: "Configure" },
            { name: "Bank Transfer", emoji: "🏦", desc: "Direct bank transfer", color: "#64748b", status: "Manual" },
          ].map((m, i) => (
            <div key={i} style={{ background: "rgba(30,35,55,0.5)", borderRadius: 12, padding: 16, display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 24 }}>{m.emoji}</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: m.status === "Active" ? "#22c55e" : m.status === "Configure" ? "#f59e0b" : "rgb(100,116,139)", background: m.status === "Active" ? "rgba(34,197,94,0.1)" : m.status === "Configure" ? "rgba(245,158,11,0.1)" : "rgba(100,116,139,0.1)", borderRadius: 6, padding: "2px 8px" }}>{m.status}</span>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: "white" }}>{m.name}</div>
              <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{m.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Transactions Table */}
      <div className="glass-card" style={{ overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: "white" }}>Transaction History</h3>
          <span style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{payments.length} transactions</span>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Transaction ID</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i}>{Array(6).fill(0).map((_, j) => <td key={j}><div className="skeleton" style={{ height: 16, width: j === 0 ? 100 : 70 }} /></td>)}</tr>
                ))
              ) : payments.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ textAlign: "center", padding: "60px 20px", color: "rgb(100,116,139)" }}>
                    <CreditCard size={40} style={{ margin: "0 auto 12px", opacity: 0.3 }} />
                    <div style={{ fontSize: 15, fontWeight: 600, color: "white", marginBottom: 4 }}>No payments yet</div>
                    <div style={{ fontSize: 13 }}>Subscribe to a plan to get started</div>
                  </td>
                </tr>
              ) : (
                payments.map(p => (
                  <tr key={p.id}>
                    <td><span style={{ fontFamily: "monospace", fontSize: 12, color: "#6366f1" }}>{p.invoiceNumber || "—"}</span></td>
                    <td><span style={{ fontWeight: 700, color: "#22c55e" }}>{p.currency} {parseFloat(p.amount).toLocaleString()}</span></td>
                    <td>
                      <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "rgb(148,163,184)" }}>
                        <span>{METHOD_ICONS[p.method] || "💰"}</span>
                        <span style={{ textTransform: "capitalize" }}>{p.method.replace("_", " ")}</span>
                      </span>
                    </td>
                    <td><span className={`badge-${STATUS_COLORS[p.status] || "warning"}`}>{p.status}</span></td>
                    <td><span style={{ fontFamily: "monospace", fontSize: 11, color: "rgb(100,116,139)" }}>{p.transactionId || "—"}</span></td>
                    <td><span style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{new Date(p.createdAt).toLocaleDateString()}</span></td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}

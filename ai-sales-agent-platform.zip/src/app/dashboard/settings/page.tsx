"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Settings, Bot, MessageSquare, Database, CreditCard, Save, Eye, EyeOff, CheckCircle, AlertCircle } from "lucide-react";
import toast from "react-hot-toast";

const TABS = [
  { id: "ai", label: "AI Settings", icon: <Bot size={16} />, color: "#f59e0b" },
  { id: "whatsapp", label: "WhatsApp", icon: <MessageSquare size={16} />, color: "#22c55e" },
  { id: "sheets", label: "Google Sheets", icon: <Database size={16} />, color: "#3b82f6" },
  { id: "payments", label: "Payments", icon: <CreditCard size={16} />, color: "#8b5cf6" },
];

interface AppSettings {
  id?: number;
  openaiApiKey?: string;
  openaiModel?: string;
  openaiSystemPrompt?: string;
  aiAutoReply?: boolean;
  aiLeadQualification?: boolean;
  aiFollowUp?: boolean;
  followUpDelayHours?: number;
  whatsappPhoneId?: string;
  whatsappToken?: string;
  whatsappWebhookVerifyToken?: string;
  googleSheetsId?: string;
  jazzcashMerchantId?: string;
  jazzcashPassword?: string;
  easypaisaStoreId?: string;
  easypaisaHashKey?: string;
  stripePublishableKey?: string;
  stripeSecretKey?: string;
}

const OPENAI_MODELS = ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("ai");
  const [settings, setSettings] = useState<AppSettings>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetch("/api/settings")
      .then(r => r.json())
      .then(data => { if (data.settings) setSettings(data.settings); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(settings) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      setSettings(data.settings);
      toast.success("Settings saved!");
    } catch { toast.error("Failed to save"); }
    finally { setSaving(false); }
  };

  const update = (key: keyof AppSettings, value: string | boolean | number) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const toggleSecret = (key: string) => setShowSecrets(prev => ({ ...prev, [key]: !prev[key] }));

  const SecretInput = ({ field, placeholder, label }: { field: keyof AppSettings; placeholder?: string; label: string }) => (
    <div>
      <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>{label}</label>
      <div style={{ position: "relative" }}>
        <input
          className="input-field"
          type={showSecrets[field] ? "text" : "password"}
          value={(settings[field] as string) || ""}
          onChange={e => update(field, e.target.value)}
          placeholder={placeholder || `Enter ${label}...`}
          style={{ paddingRight: 40 }}
        />
        <button type="button" onClick={() => toggleSecret(field as string)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}>
          {showSecrets[field] ? <EyeOff size={15} /> : <Eye size={15} />}
        </button>
      </div>
    </div>
  );

  return (
    <DashboardLayout title="Settings">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <Settings size={24} style={{ color: "#64748b" }} /> Settings
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>Configure your AI, WhatsApp, and payment integrations</p>
        </div>
        <button onClick={save} disabled={saving} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Save size={16} /> {saving ? "Saving..." : "Save Settings"}
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 20 }}>
        {/* Sidebar Tabs */}
        <div className="glass-card" style={{ padding: 12, height: "fit-content" }}>
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "11px 14px", borderRadius: 10, border: "1px solid", cursor: "pointer", textAlign: "left", marginBottom: 4, transition: "all 0.2s", borderColor: activeTab === tab.id ? tab.color : "transparent", background: activeTab === tab.id ? `rgba(${tab.color === "#f59e0b" ? "245,158,11" : tab.color === "#22c55e" ? "34,197,94" : tab.color === "#3b82f6" ? "59,130,246" : "139,92,246"},0.1)` : "transparent" }}>
              <span style={{ color: activeTab === tab.id ? tab.color : "rgb(100,116,139)" }}>{tab.icon}</span>
              <span style={{ fontSize: 13, fontWeight: 600, color: activeTab === tab.id ? "white" : "rgb(148,163,184)" }}>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="glass-card" style={{ padding: 28 }}>
          {loading ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {Array(6).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 48, borderRadius: 10 }} />)}
            </div>
          ) : (
            <>
              {/* AI Settings */}
              {activeTab === "ai" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}><Bot size={16} style={{ color: "#f59e0b" }} />OpenAI Configuration</h3>
                    <p style={{ fontSize: 12, color: "rgb(100,116,139)", marginBottom: 20 }}>Connect your OpenAI account to power the AI Sales Agent</p>
                  </div>
                  <SecretInput field="openaiApiKey" label="OpenAI API Key" placeholder="sk-..." />
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>AI Model</label>
                    <select className="input-field" value={settings.openaiModel || "gpt-4o-mini"} onChange={e => update("openaiModel", e.target.value)}>
                      {OPENAI_MODELS.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>System Prompt</label>
                    <textarea
                      className="input-field"
                      value={settings.openaiSystemPrompt || ""}
                      onChange={e => update("openaiSystemPrompt", e.target.value)}
                      rows={6}
                      placeholder="You are a professional AI sales agent..."
                      style={{ resize: "vertical" }}
                    />
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 4 }}>This defines how the AI behaves in all conversations</div>
                  </div>

                  <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 20 }}>
                    <h4 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 14 }}>AI Automation</h4>
                    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                      {[
                        { key: "aiAutoReply" as const, label: "Auto Reply", desc: "AI automatically replies to customer messages" },
                        { key: "aiLeadQualification" as const, label: "Lead Qualification", desc: "AI automatically qualifies and scores leads" },
                        { key: "aiFollowUp" as const, label: "Auto Follow-up", desc: "AI follows up with inactive customers" },
                      ].map(item => (
                        <div key={item.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", background: "rgba(30,35,55,0.5)", borderRadius: 10 }}>
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600, color: "white" }}>{item.label}</div>
                            <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{item.desc}</div>
                          </div>
                          <button onClick={() => update(item.key, !settings[item.key])} style={{ width: 44, height: 24, borderRadius: 12, border: "none", cursor: "pointer", background: settings[item.key] ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "rgba(30,35,55,0.8)", position: "relative", transition: "all 0.2s", flexShrink: 0 }}>
                            <div style={{ position: "absolute", width: 18, height: 18, borderRadius: "50%", background: "white", top: 3, left: settings[item.key] ? 23 : 3, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.3)" }} />
                          </button>
                        </div>
                      ))}
                    </div>
                    <div style={{ marginTop: 12 }}>
                      <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Follow-up Delay (Hours)</label>
                      <input className="input-field" type="number" min="1" max="168" value={settings.followUpDelayHours || 24} onChange={e => update("followUpDelayHours", parseInt(e.target.value))} style={{ maxWidth: 200 }} />
                    </div>
                  </div>
                </div>
              )}

              {/* WhatsApp Settings */}
              {activeTab === "whatsapp" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}><MessageSquare size={16} style={{ color: "#22c55e" }} />WhatsApp Cloud API</h3>
                    <p style={{ fontSize: 12, color: "rgb(100,116,139)", marginBottom: 4 }}>Connect Meta WhatsApp Business API</p>
                    <div style={{ padding: 12, background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)", borderRadius: 8 }}>
                      <p style={{ fontSize: 12, color: "#3b82f6" }}>📱 Get your credentials from <strong>developers.facebook.com</strong> → WhatsApp → API Setup</p>
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Phone Number ID</label>
                    <input className="input-field" value={settings.whatsappPhoneId || ""} onChange={e => update("whatsappPhoneId", e.target.value)} placeholder="1234567890123456" />
                  </div>
                  <SecretInput field="whatsappToken" label="Access Token" placeholder="EAAxxxx..." />
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Webhook Verify Token</label>
                    <input className="input-field" value={settings.whatsappWebhookVerifyToken || ""} onChange={e => update("whatsappWebhookVerifyToken", e.target.value)} placeholder="my-verify-token-123" />
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 4 }}>Webhook URL: <code style={{ color: "#6366f1" }}>{typeof window !== "undefined" ? window.location.origin : ""}/api/whatsapp/webhook</code></div>
                  </div>
                </div>
              )}

              {/* Google Sheets */}
              {activeTab === "sheets" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 8 }}><Database size={16} style={{ color: "#3b82f6" }} />Google Sheets Sync</h3>
                    <p style={{ fontSize: 12, color: "rgb(100,116,139)", marginBottom: 4 }}>Auto-sync customers, orders, and reports to Google Sheets</p>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Google Sheets ID</label>
                    <input className="input-field" value={settings.googleSheetsId || ""} onChange={e => update("googleSheetsId", e.target.value)} placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms" />
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 4 }}>Found in the Google Sheets URL: /spreadsheets/d/[SHEET_ID]/edit</div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Service Account JSON</label>
                    <textarea className="input-field" placeholder='{"type": "service_account", "project_id": "...", ...}' rows={8} style={{ resize: "vertical", fontFamily: "monospace", fontSize: 11 }} />
                    <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 4 }}>From Google Cloud Console → IAM → Service Accounts</div>
                  </div>
                </div>
              )}

              {/* Payments */}
              {activeTab === "payments" && (
                <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Payment Gateways</h3>
                    <p style={{ fontSize: 12, color: "rgb(100,116,139)" }}>Configure payment methods for subscriptions</p>
                  </div>

                  {/* JazzCash */}
                  <div style={{ background: "rgba(30,35,55,0.5)", borderRadius: 12, padding: 20 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                      <span style={{ fontSize: 22 }}>📱</span>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>JazzCash</div>
                        <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>Mobile payments via JazzCash</div>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      <div>
                        <label style={{ fontSize: 11, color: "rgb(100,116,139)", fontWeight: 600, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>Merchant ID</label>
                        <input className="input-field" value={settings.jazzcashMerchantId || ""} onChange={e => update("jazzcashMerchantId", e.target.value)} placeholder="MC123456" style={{ fontSize: 12 }} />
                      </div>
                      <div>
                        <label style={{ fontSize: 11, color: "rgb(100,116,139)", fontWeight: 600, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>Password</label>
                        <input className="input-field" type="password" value={settings.jazzcashPassword || ""} onChange={e => update("jazzcashPassword", e.target.value)} placeholder="••••••••" style={{ fontSize: 12 }} />
                      </div>
                    </div>
                  </div>

                  {/* EasyPaisa */}
                  <div style={{ background: "rgba(30,35,55,0.5)", borderRadius: 12, padding: 20 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                      <span style={{ fontSize: 22 }}>💚</span>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>EasyPaisa</div>
                        <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>Telenor EasyPaisa payments</div>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      <div>
                        <label style={{ fontSize: 11, color: "rgb(100,116,139)", fontWeight: 600, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>Store ID</label>
                        <input className="input-field" value={settings.easypaisaStoreId || ""} onChange={e => update("easypaisaStoreId", e.target.value)} placeholder="Store ID" style={{ fontSize: 12 }} />
                      </div>
                      <div>
                        <label style={{ fontSize: 11, color: "rgb(100,116,139)", fontWeight: 600, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>Hash Key</label>
                        <input className="input-field" type="password" value={settings.easypaisaHashKey || ""} onChange={e => update("easypaisaHashKey", e.target.value)} placeholder="••••••••" style={{ fontSize: 12 }} />
                      </div>
                    </div>
                  </div>

                  {/* Stripe */}
                  <div style={{ background: "rgba(30,35,55,0.5)", borderRadius: 12, padding: 20 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                      <span style={{ fontSize: 22 }}>💳</span>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>Stripe</div>
                        <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>International card payments</div>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      <div>
                        <label style={{ fontSize: 11, color: "rgb(100,116,139)", fontWeight: 600, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.05em" }}>Publishable Key</label>
                        <input className="input-field" value={settings.stripePublishableKey || ""} onChange={e => update("stripePublishableKey", e.target.value)} placeholder="pk_test_..." style={{ fontSize: 12 }} />
                      </div>
                      <SecretInput field="stripeSecretKey" label="Secret Key" placeholder="sk_test_..." />
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

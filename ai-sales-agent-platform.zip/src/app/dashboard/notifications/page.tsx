"use client";

import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Bell, Check, CheckCheck, Package, Users, CreditCard, Bot, Settings, Trash2 } from "lucide-react";
import toast from "react-hot-toast";

interface Notification {
  id: number;
  type: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
  metadata: unknown;
}

const TYPE_CONFIG: Record<string, { icon: React.ReactNode; color: string; bg: string }> = {
  order: { icon: <Package size={16} />, color: "#6366f1", bg: "rgba(99,102,241,0.15)" },
  customer: { icon: <Users size={16} />, color: "#8b5cf6", bg: "rgba(139,92,246,0.15)" },
  payment: { icon: <CreditCard size={16} />, color: "#22c55e", bg: "rgba(34,197,94,0.15)" },
  subscription: { icon: <CreditCard size={16} />, color: "#f59e0b", bg: "rgba(245,158,11,0.15)" },
  ai_event: { icon: <Bot size={16} />, color: "#ec4899", bg: "rgba(236,72,153,0.15)" },
  system: { icon: <Settings size={16} />, color: "#64748b", bg: "rgba(100,116,139,0.15)" },
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/notifications?limit=50");
      const data = await res.json();
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchNotifications(); }, []);

  const markAllRead = async () => {
    const res = await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ markAllRead: true }),
    });
    if (res.ok) {
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
      toast.success("All marked as read");
    }
  };

  const markRead = async (id: number) => {
    const res = await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: [id] }),
    });
    if (res.ok) {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    }
  };

  const filtered = filter === "all" ? notifications : filter === "unread" ? notifications.filter(n => !n.isRead) : notifications.filter(n => n.type === filter);

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (mins < 60) return `${mins}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  // Add sample notifications if empty
  const addSampleNotification = async () => {
    const samples = [
      { type: "order", title: "New Order Received", message: "Order #ORD-001 has been placed by Ahmed Khan for PKR 5,999" },
      { type: "customer", title: "New Customer Registered", message: "Sara Ahmed has joined your platform via WhatsApp" },
      { type: "ai_event", title: "AI Lead Qualified", message: "AI has qualified Muhammad Ali as a high-value lead with 85% score" },
      { type: "payment", title: "Payment Received", message: "Payment of PKR 12,500 received via JazzCash for Order #ORD-002" },
    ];
    const sample = samples[Math.floor(Math.random() * samples.length)];
    await fetch("/api/notifications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...sample, metadata: {} }),
    });
    fetchNotifications();
    toast.success("Sample notification added!");
  };

  return (
    <DashboardLayout title="Notifications">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <Bell size={24} style={{ color: "#a855f7" }} /> Notifications
            {unreadCount > 0 && <span style={{ background: "#ef4444", color: "white", borderRadius: "50%", width: 24, height: 24, fontSize: 12, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{unreadCount}</span>}
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>{notifications.length} total, {unreadCount} unread</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={addSampleNotification} style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 10, padding: "9px 16px", color: "#6366f1", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>+ Sample</button>
          {unreadCount > 0 && (
            <button onClick={markAllRead} style={{ display: "flex", alignItems: "center", gap: 7, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, padding: "9px 16px", color: "#22c55e", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
              <CheckCheck size={15} /> Mark All Read
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {[
          { key: "all", label: "All" },
          { key: "unread", label: `Unread (${unreadCount})` },
          { key: "order", label: "Orders" },
          { key: "customer", label: "Customers" },
          { key: "payment", label: "Payments" },
          { key: "ai_event", label: "AI Events" },
          { key: "system", label: "System" },
        ].map(f => (
          <button key={f.key} onClick={() => setFilter(f.key)} style={{ padding: "7px 14px", borderRadius: 8, border: "1px solid", fontSize: 12, fontWeight: 600, cursor: "pointer", borderColor: filter === f.key ? "#6366f1" : "rgba(255,255,255,0.08)", background: filter === f.key ? "rgba(99,102,241,0.15)" : "rgba(30,35,55,0.6)", color: filter === f.key ? "#6366f1" : "rgb(148,163,184)" }}>
            {f.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="glass-card" style={{ overflow: "hidden" }}>
        {loading ? (
          Array(8).fill(0).map((_, i) => (
            <div key={i} style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.04)", display: "flex", gap: 14 }}>
              <div className="skeleton" style={{ width: 40, height: 40, borderRadius: "50%", flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div className="skeleton" style={{ height: 14, width: "40%", marginBottom: 8 }} />
                <div className="skeleton" style={{ height: 12, width: "70%" }} />
              </div>
            </div>
          ))
        ) : filtered.length === 0 ? (
          <div style={{ padding: "60px 40px", textAlign: "center", color: "rgb(100,116,139)" }}>
            <Bell size={48} style={{ margin: "0 auto 16px", opacity: 0.2 }} />
            <h3 style={{ fontSize: 16, fontWeight: 600, color: "white", marginBottom: 6 }}>No notifications</h3>
            <p style={{ fontSize: 13 }}>New notifications will appear here</p>
          </div>
        ) : (
          filtered.map((n, i) => {
            const config = TYPE_CONFIG[n.type] || TYPE_CONFIG.system;
            return (
              <div key={n.id} onClick={() => !n.isRead && markRead(n.id)} style={{ padding: "16px 20px", borderBottom: i < filtered.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none", display: "flex", gap: 14, alignItems: "flex-start", cursor: !n.isRead ? "pointer" : "default", background: !n.isRead ? "rgba(99,102,241,0.04)" : "transparent", transition: "background 0.15s", position: "relative" }}>
                {!n.isRead && <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 3, background: "#6366f1", borderRadius: "0 2px 2px 0" }} />}
                <div style={{ width: 40, height: 40, borderRadius: 12, background: config.bg, display: "flex", alignItems: "center", justifyContent: "center", color: config.color, flexShrink: 0 }}>
                  {config.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
                    <div style={{ fontSize: 14, fontWeight: n.isRead ? 500 : 700, color: "white" }}>{n.title}</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
                      <span style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{timeAgo(n.createdAt)}</span>
                      {!n.isRead && <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#6366f1" }} />}
                    </div>
                  </div>
                  <div style={{ fontSize: 13, color: "rgb(148,163,184)", marginTop: 3, lineHeight: 1.5 }}>{n.message}</div>
                  <div style={{ marginTop: 8 }}>
                    <span style={{ background: config.bg, color: config.color, borderRadius: 6, padding: "2px 8px", fontSize: 11, fontWeight: 600, textTransform: "capitalize" }}>{n.type.replace("_", " ")}</span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </DashboardLayout>
  );
}

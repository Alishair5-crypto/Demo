"use client";

import { useState, useEffect, useCallback } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { BookOpen, Plus, Search, Trash2, Edit, X, Tag, Brain } from "lucide-react";
import toast from "react-hot-toast";

interface KBItem {
  id: number;
  type: string;
  title: string;
  content: string;
  tags: string[];
  isActive: boolean;
  priority: number;
  createdAt: string;
}

const TYPE_CONFIG: Record<string, { color: string; bg: string; icon: string; label: string }> = {
  product: { color: "#6366f1", bg: "rgba(99,102,241,0.15)", icon: "🛍️", label: "Product" },
  faq: { color: "#22c55e", bg: "rgba(34,197,94,0.15)", icon: "❓", label: "FAQ" },
  pricing: { color: "#f59e0b", bg: "rgba(245,158,11,0.15)", icon: "💰", label: "Pricing" },
  company: { color: "#8b5cf6", bg: "rgba(139,92,246,0.15)", icon: "🏢", label: "Company" },
  policy: { color: "#ec4899", bg: "rgba(236,72,153,0.15)", icon: "📋", label: "Policy" },
};

export default function KnowledgeBasePage() {
  const [items, setItems] = useState<KBItem[]>([]);
  const [total, setTotal] = useState(0);
  const [typeFilter, setTypeFilter] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState<KBItem | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ type: "product", title: "", content: "", tags: "", priority: "0" });

  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ limit: "50" });
      if (typeFilter) params.set("type", typeFilter);
      if (search) params.set("search", search);
      const res = await fetch(`/api/knowledge-base?${params}`);
      const data = await res.json();
      setItems(data.items || []);
      setTotal(data.total || 0);
    } catch { toast.error("Failed to load"); }
    finally { setLoading(false); }
  }, [typeFilter, search]);

  useEffect(() => { fetchItems(); }, [fetchItems]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const body = { ...form, tags: form.tags.split(",").map(t => t.trim()).filter(Boolean), priority: parseInt(form.priority) || 0 };
      const url = editItem ? `/api/knowledge-base/${editItem.id}` : "/api/knowledge-base";
      const method = editItem ? "PATCH" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error); return; }
      toast.success(editItem ? "Updated!" : "Added to knowledge base!");
      setShowModal(false);
      setEditItem(null);
      setForm({ type: "product", title: "", content: "", tags: "", priority: "0" });
      fetchItems();
    } catch { toast.error("Failed to save"); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Remove this item?")) return;
    const res = await fetch(`/api/knowledge-base/${id}`, { method: "DELETE" });
    if (res.ok) { toast.success("Removed"); fetchItems(); }
  };

  const openEdit = (item: KBItem) => {
    setEditItem(item);
    setForm({ type: item.type, title: item.title, content: item.content, tags: (item.tags || []).join(", "), priority: String(item.priority || 0) });
    setShowModal(true);
  };

  const typeCounts = Object.keys(TYPE_CONFIG).reduce((acc, t) => {
    acc[t] = items.filter(i => i.type === t).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <DashboardLayout title="Knowledge Base">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "white", marginBottom: 4, display: "flex", alignItems: "center", gap: 10 }}>
            <BookOpen size={24} style={{ color: "#f97316" }} /> Knowledge Base
          </h1>
          <p style={{ color: "rgb(148,163,184)", fontSize: 13 }}>
            <Brain size={13} style={{ display: "inline", marginRight: 4 }} />
            AI uses this data to answer customer questions
          </p>
        </div>
        <button onClick={() => { setEditItem(null); setForm({ type: "product", title: "", content: "", tags: "", priority: "0" }); setShowModal(true); }} className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <Plus size={16} /> Add Entry
        </button>
      </div>

      {/* Type Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 12, marginBottom: 20 }}>
        {[{ key: "", label: "All", icon: "📚", color: "#64748b", bg: "rgba(100,116,139,0.15)" }, ...Object.entries(TYPE_CONFIG).map(([k, v]) => ({ key: k, label: v.label, icon: v.icon, color: v.color, bg: v.bg }))].map(t => (
          <button
            key={t.key}
            onClick={() => setTypeFilter(t.key)}
            style={{ padding: "14px 12px", borderRadius: 12, border: "1px solid", cursor: "pointer", textAlign: "center", transition: "all 0.2s", borderColor: typeFilter === t.key ? t.color : "rgba(255,255,255,0.06)", background: typeFilter === t.key ? t.bg : "rgba(22,27,42,0.5)" }}
          >
            <div style={{ fontSize: 22, marginBottom: 4 }}>{t.icon}</div>
            <div style={{ fontSize: 12, fontWeight: 700, color: "white" }}>{t.label}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: t.color, marginTop: 4 }}>{t.key ? typeCounts[t.key] || 0 : total}</div>
          </button>
        ))}
      </div>

      {/* Search */}
      <div style={{ position: "relative", marginBottom: 20 }}>
        <Search size={15} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />
        <input className="input-field" placeholder="Search knowledge base..." value={search} onChange={e => setSearch(e.target.value)} style={{ paddingLeft: 36, maxWidth: 400 }} />
      </div>

      {/* Grid */}
      {loading ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
          {Array(6).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: 180, borderRadius: 16 }} />)}
        </div>
      ) : items.length === 0 ? (
        <div className="glass-card" style={{ padding: "60px 40px", textAlign: "center" }}>
          <BookOpen size={48} style={{ margin: "0 auto 16px", opacity: 0.2, color: "#f97316" }} />
          <h3 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 6 }}>Knowledge base is empty</h3>
          <p style={{ fontSize: 13, color: "rgb(100,116,139)", marginBottom: 20 }}>Add products, FAQs, pricing, and company info to help your AI respond better</p>
          <button onClick={() => setShowModal(true)} className="btn-primary">Add First Entry</button>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
          {items.map(item => {
            const typeConfig = TYPE_CONFIG[item.type] || { color: "#64748b", bg: "rgba(100,116,139,0.15)", icon: "📄", label: item.type };
            return (
              <div key={item.id} className="glass-card" style={{ padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 18 }}>{typeConfig.icon}</span>
                    <span style={{ padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: typeConfig.bg, color: typeConfig.color }}>{typeConfig.label}</span>
                    {item.priority > 0 && <span style={{ background: "rgba(245,158,11,0.15)", color: "#f59e0b", borderRadius: 20, padding: "2px 8px", fontSize: 11, fontWeight: 600 }}>P{item.priority}</span>}
                  </div>
                  <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                    <button onClick={() => openEdit(item)} style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 7, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#6366f1" }}><Edit size={12} /></button>
                    <button onClick={() => handleDelete(item.id)} style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 7, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#ef4444" }}><Trash2 size={12} /></button>
                  </div>
                </div>
                <div>
                  <h4 style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 6, lineHeight: 1.4 }}>{item.title}</h4>
                  <p style={{ fontSize: 12, color: "rgb(148,163,184)", lineHeight: 1.6, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical" }}>{item.content}</p>
                </div>
                {(item.tags || []).length > 0 && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {(item.tags || []).map((tag, i) => (
                      <span key={i} style={{ background: "rgba(30,35,55,0.7)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 6, padding: "2px 7px", fontSize: 11, color: "rgb(100,116,139)", display: "flex", alignItems: "center", gap: 4 }}>
                        <Tag size={9} />{tag}
                      </span>
                    ))}
                  </div>
                )}
                <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: "auto" }}>{new Date(item.createdAt).toLocaleDateString()}</div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" style={{ maxWidth: 600 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
              <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>{editItem ? "Edit Entry" : "Add Knowledge Base Entry"}</h2>
              <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", color: "rgb(100,116,139)", cursor: "pointer" }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Type *</label>
                    <select className="input-field" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} required>
                      {Object.entries(TYPE_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Priority (0-10)</label>
                    <input className="input-field" type="number" min="0" max="10" value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} />
                  </div>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Title *</label>
                  <input className="input-field" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. Premium Widget Pro - PKR 5,999" required />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Content *</label>
                  <textarea className="input-field" value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} placeholder="Full description, features, answers, or details..." rows={6} style={{ resize: "vertical" }} required />
                  <div style={{ fontSize: 11, color: "rgb(100,116,139)", marginTop: 4 }}>💡 This content will be used by AI to answer customer questions</div>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Tags (comma separated)</label>
                  <input className="input-field" value={form.tags} onChange={e => setForm({ ...form, tags: e.target.value })} placeholder="premium, electronics, sale" />
                </div>
                <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                  <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: "11px", background: "rgba(30,35,55,0.8)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgb(148,163,184)", cursor: "pointer", fontSize: 14, fontWeight: 600 }}>Cancel</button>
                  <button type="submit" disabled={submitting} className="btn-primary" style={{ flex: 2, padding: "11px" }}>{submitting ? "Saving..." : editItem ? "Update Entry" : "Add to Knowledge Base"}</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useStore } from "@/store/useStore";
import {
  LayoutDashboard, Users, Package, MessageSquare, Bot,
  BarChart3, FileText, BookOpen, Bell, User, Settings,
  CreditCard, Crown, TrendingUp, TrendingDown,
  ArrowUpRight, Zap, Activity, CheckCircle
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";
import { formatCurrency } from "@/lib/utils";

interface Stats {
  totalCustomers: number;
  newCustomersThisMonth: number;
  customersGrowth: number;
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  totalRevenue: number;
  monthRevenue: number;
  revenueGrowth: number;
  totalConversations: number;
  activeConversations: number;
  aiMessages: number;
  unreadNotifications: number;
  conversionRate: number;
}

const MODULE_CARDS = [
  { href: "/dashboard/customers", icon: "👥", label: "Customers", desc: "Manage contacts & leads", gradient: "linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)", glow: "rgba(99,102,241,0.3)" },
  { href: "/dashboard/orders", icon: "📦", label: "Orders", desc: "Track & manage orders", gradient: "linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)", glow: "rgba(139,92,246,0.3)" },
  { href: "/dashboard/whatsapp", icon: "💬", label: "WhatsApp", desc: "Live chat & automation", gradient: "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)", glow: "rgba(34,197,94,0.3)" },
  { href: "/dashboard/ai", icon: "🤖", label: "AI Assistant", desc: "Powered by OpenAI GPT", gradient: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)", glow: "rgba(245,158,11,0.3)" },
  { href: "/dashboard/analytics", icon: "📊", label: "Analytics", desc: "Revenue & sales insights", gradient: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)", glow: "rgba(59,130,246,0.3)" },
  { href: "/dashboard/reports", icon: "📄", label: "Reports", desc: "PDF & Excel exports", gradient: "linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)", glow: "rgba(20,184,166,0.3)" },
  { href: "/dashboard/knowledge-base", icon: "🧠", label: "Knowledge Base", desc: "Products, FAQs & policies", gradient: "linear-gradient(135deg, #f97316 0%, #ea580c 100%)", glow: "rgba(249,115,22,0.3)" },
  { href: "/dashboard/notifications", icon: "🔔", label: "Notifications", desc: "Alerts & updates", gradient: "linear-gradient(135deg, #a855f7 0%, #9333ea 100%)", glow: "rgba(168,85,247,0.3)" },
  { href: "/dashboard/profile", icon: "👤", label: "Profile", desc: "Company & account info", gradient: "linear-gradient(135deg, #64748b 0%, #475569 100%)", glow: "rgba(100,116,139,0.3)" },
  { href: "/dashboard/settings", icon: "⚙️", label: "Settings", desc: "API keys & configuration", gradient: "linear-gradient(135deg, #334155 0%, #1e293b 100%)", glow: "rgba(51,65,85,0.3)" },
  { href: "/dashboard/subscriptions", icon: "💎", label: "Subscription", desc: "Silver, Gold, Diamond plans", gradient: "linear-gradient(135deg, #eab308 0%, #ca8a04 100%)", glow: "rgba(234,179,8,0.3)" },
  { href: "/dashboard/payments", icon: "💳", label: "Payments", desc: "JazzCash, EasyPaisa, Stripe", gradient: "linear-gradient(135deg, #10b981 0%, #059669 100%)", glow: "rgba(16,185,129,0.3)" },
];

const COLORS = ["#6366f1", "#8b5cf6", "#ec4899", "#22c55e", "#f59e0b"];

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) => {
  if (active && payload && payload.length) {
    return (
      <div style={{ background: "rgba(22,27,42,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, padding: "10px 14px", fontSize: 13 }}>
        <p style={{ color: "rgb(148,163,184)", marginBottom: 4 }}>{label}</p>
        <p style={{ color: "#6366f1", fontWeight: 700 }}>{formatCurrency(payload[0]?.value || 0)}</p>
      </div>
    );
  }
  return null;
};

export default function DashboardPage() {
  const router = useRouter();
  const { user } = useStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [revenueData, setRevenueData] = useState<{ month: string; revenue: number }[]>([]);
  const [ordersByStatus, setOrdersByStatus] = useState<{ status: string; count: number }[]>([]);
  const [recentOrders, setRecentOrders] = useState<{ id: number; orderNumber: string; status: string; total: string; createdAt: string }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard/stats")
      .then(r => r.json())
      .then(data => {
        setStats(data.stats);
        setRevenueData(data.revenueByMonth || []);
        setOrdersByStatus(data.ordersByStatus || []);
        setRecentOrders(data.recentOrders || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const statCards = [
    {
      label: "Total Revenue",
      value: formatCurrency(stats?.totalRevenue || 0),
      sub: formatCurrency(stats?.monthRevenue || 0) + " this month",
      icon: <TrendingUp size={20} />,
      growth: stats?.revenueGrowth,
      color: "#6366f1",
      bg: "rgba(99,102,241,0.1)",
    },
    {
      label: "Total Customers",
      value: stats?.totalCustomers?.toLocaleString() || "0",
      sub: `+${stats?.newCustomersThisMonth || 0} this month`,
      icon: <Users size={20} />,
      growth: stats?.customersGrowth,
      color: "#8b5cf6",
      bg: "rgba(139,92,246,0.1)",
    },
    {
      label: "Total Orders",
      value: stats?.totalOrders?.toLocaleString() || "0",
      sub: `${stats?.pendingOrders || 0} pending`,
      icon: <Package size={20} />,
      color: "#ec4899",
      bg: "rgba(236,72,153,0.1)",
    },
    {
      label: "Conversion Rate",
      value: `${stats?.conversionRate || 0}%`,
      sub: `${stats?.activeConversations || 0} active chats`,
      icon: <Zap size={20} />,
      color: "#22c55e",
      bg: "rgba(34,197,94,0.1)",
    },
  ];

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = { pending: "warning", completed: "success", cancelled: "danger", delivered: "info", confirmed: "purple" };
    return colors[status] || "info";
  };

  return (
    <DashboardLayout title="Dashboard">
      {/* Welcome Header */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <h1 style={{ fontSize: 26, fontWeight: 800, color: "white", letterSpacing: "-0.5px", marginBottom: 4 }}>
              Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"},{" "}
              <span className="gradient-text">{user?.firstName} 👋</span>
            </h1>
            <p style={{ color: "rgb(148,163,184)", fontSize: 14 }}>
              Here&apos;s what&apos;s happening with your business today
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div className="pulse-dot" style={{ background: "#22c55e", color: "#22c55e" }} />
            <span style={{ fontSize: 13, color: "rgb(148,163,184)", fontWeight: 500 }}>AI Agent Online</span>
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="stagger-children" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16, marginBottom: 28 }}>
        {statCards.map((card, i) => (
          <div key={i} className="stat-card">
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: card.bg, display: "flex", alignItems: "center", justifyContent: "center", color: card.color }}>
                {card.icon}
              </div>
              {card.growth !== undefined && (
                <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 600, color: card.growth >= 0 ? "#22c55e" : "#ef4444" }}>
                  {card.growth >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {Math.abs(card.growth)}%
                </div>
              )}
            </div>
            <div style={{ fontSize: 26, fontWeight: 800, color: "white", letterSpacing: "-0.5px", marginBottom: 4 }}>
              {loading ? <div className="skeleton" style={{ height: 30, width: 100 }} /> : card.value}
            </div>
            <div style={{ fontSize: 12, color: "rgb(148,163,184)" }}>
              {loading ? <div className="skeleton" style={{ height: 16, width: 140, marginTop: 4 }} /> : (
                <><span style={{ color: "rgb(148,163,184)" }}>{card.label}</span> · {card.sub}</>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20, marginBottom: 28 }}>
        {/* Revenue Chart */}
        <div className="glass-card" style={{ padding: 24 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 2 }}>Revenue Overview</h3>
              <p style={{ fontSize: 12, color: "rgb(148,163,184)" }}>Last 6 months performance</p>
            </div>
            <div style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 8, padding: "4px 12px", fontSize: 12, color: "#6366f1", fontWeight: 600 }}>
              Monthly
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "rgb(100,116,139)" }} axisLine={false} tickLine={false} tickFormatter={(v) => `₨${(v/1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={2.5} fill="url(#revenueGrad)" dot={{ fill: "#6366f1", strokeWidth: 0, r: 4 }} activeDot={{ r: 6 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Orders by Status */}
        <div className="glass-card" style={{ padding: 24 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "white", marginBottom: 4 }}>Orders by Status</h3>
          <p style={{ fontSize: 12, color: "rgb(148,163,184)", marginBottom: 16 }}>Distribution breakdown</p>
          {ordersByStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={170}>
              <PieChart>
                <Pie data={ordersByStatus} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={65} innerRadius={40}>
                  {ordersByStatus.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Legend formatter={(v) => <span style={{ fontSize: 11, color: "rgb(148,163,184)", textTransform: "capitalize" }}>{v}</span>} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: 170, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "rgb(100,116,139)" }}>
              <Activity size={32} style={{ marginBottom: 8, opacity: 0.4 }} />
              <span style={{ fontSize: 13 }}>No orders yet</span>
            </div>
          )}
        </div>
      </div>

      {/* Recent Orders & Module Cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 28 }}>
        {/* Recent Orders */}
        {recentOrders.length > 0 && (
          <div className="glass-card" style={{ padding: 24 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "white" }}>Recent Orders</h3>
              <button onClick={() => router.push("/dashboard/orders")} style={{ background: "none", border: "none", color: "#6366f1", fontSize: 13, cursor: "pointer", fontWeight: 600, display: "flex", alignItems: "center", gap: 4 }}>
                View all <ArrowUpRight size={14} />
              </button>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Status</th>
                  <th>Payment</th>
                  <th>Total</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map(order => (
                  <tr key={order.id} onClick={() => router.push("/dashboard/orders")} style={{ cursor: "pointer" }}>
                    <td><span style={{ fontWeight: 600, color: "white", fontSize: 13 }}>{order.orderNumber}</span></td>
                    <td><span className={`badge-${getStatusColor(order.status)}`}>{order.status}</span></td>
                    <td><span className={`badge-${order.status === "completed" ? "success" : "warning"}`}>{order.status === "completed" ? "Paid" : "Pending"}</span></td>
                    <td><span style={{ fontWeight: 700, color: "#22c55e" }}>{formatCurrency(parseFloat(order.total))}</span></td>
                    <td><span style={{ color: "rgb(148,163,184)", fontSize: 12 }}>{new Date(order.createdAt).toLocaleDateString()}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Module Cards Grid */}
        <div>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 16 }}>
            All Modules <span className="gradient-text">({MODULE_CARDS.length})</span>
          </h2>
          <div className="stagger-children" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: 14 }}>
            {MODULE_CARDS.map((card) => (
              <div
                key={card.href}
                className="module-card"
                onClick={() => router.push(card.href)}
              >
                <div
                  style={{
                    width: 52, height: 52, borderRadius: 14,
                    background: card.gradient,
                    boxShadow: `0 8px 20px ${card.glow}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 22, margin: "0 auto 12px",
                  }}
                >
                  {card.icon}
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "white", marginBottom: 4 }}>{card.label}</div>
                <div style={{ fontSize: 11, color: "rgb(100,116,139)" }}>{card.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Stats Bottom */}
      <div style={{ marginTop: 28, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12 }}>
        {[
          { label: "AI Messages (30d)", value: stats?.aiMessages || 0, icon: "🤖", color: "#f59e0b" },
          { label: "Active Conversations", value: stats?.activeConversations || 0, icon: "💬", color: "#22c55e" },
          { label: "Completed Orders", value: stats?.completedOrders || 0, icon: "✅", color: "#6366f1" },
          { label: "Pending Orders", value: stats?.pendingOrders || 0, icon: "⏳", color: "#f97316" },
        ].map((item, i) => (
          <div key={i} style={{ background: "rgba(22,27,42,0.5)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 12, padding: "16px 20px", display: "flex", alignItems: "center", gap: 14 }}>
            <span style={{ fontSize: 24 }}>{item.icon}</span>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, color: "white" }}>{loading ? "—" : item.value.toLocaleString()}</div>
              <div style={{ fontSize: 12, color: "rgb(100,116,139)" }}>{item.label}</div>
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  );
}

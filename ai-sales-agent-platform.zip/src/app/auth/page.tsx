"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { Eye, EyeOff, Zap, Bot, BarChart3, MessageSquare, Shield, Globe } from "lucide-react";

export default function AuthPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const [form, setForm] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    companyName: "",
    phone: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const body = mode === "login"
        ? { email: form.email, password: form.password }
        : form;

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || "Something went wrong");
        return;
      }

      toast.success(mode === "login" ? "Welcome back!" : "Account created! Starting your free trial.");
      router.push("/dashboard");
    } catch {
      toast.error("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: <Bot size={20} />, text: "AI Sales Agent on WhatsApp", color: "#6366f1" },
    { icon: <MessageSquare size={20} />, text: "Automated Customer Follow-up", color: "#8b5cf6" },
    { icon: <BarChart3 size={20} />, text: "Real-time Analytics & Reports", color: "#ec4899" },
    { icon: <Shield size={20} />, text: "Enterprise-grade Security", color: "#22c55e" },
    { icon: <Globe size={20} />, text: "Google Sheets Sync", color: "#f59e0b" },
    { icon: <Zap size={20} />, text: "3-Day Free Trial", color: "#3b82f6" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "rgb(15,17,26)", display: "flex", position: "relative", overflow: "hidden" }}>
      {/* Background orbs */}
      <div className="orb" style={{ width: 600, height: 600, background: "#6366f1", top: -200, left: -200 }} />
      <div className="orb" style={{ width: 400, height: 400, background: "#8b5cf6", bottom: -100, right: 200 }} />
      <div className="orb" style={{ width: 300, height: 300, background: "#ec4899", top: "50%", right: -100 }} />

      {/* Left Panel */}
      <div style={{ flex: 1, padding: "60px", display: "flex", flexDirection: "column", justifyContent: "center", position: "relative" }}>
        <div style={{ maxWidth: 480 }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 48 }}>
            <div className="animated-gradient" style={{ width: 44, height: 44, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Bot size={24} color="white" />
            </div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 800, color: "white", letterSpacing: "-0.5px" }}>SalesAI Pro</div>
              <div style={{ fontSize: 11, color: "rgba(148,163,184,0.8)", letterSpacing: "0.1em", textTransform: "uppercase" }}>AI Sales Platform</div>
            </div>
          </div>

          <h1 style={{ fontSize: 42, fontWeight: 800, lineHeight: 1.15, marginBottom: 16, color: "white" }}>
            Automate your sales with{" "}
            <span className="gradient-text">AI Intelligence</span>
          </h1>

          <p style={{ fontSize: 16, color: "rgb(148,163,184)", lineHeight: 1.7, marginBottom: 40 }}>
            Let AI handle your WhatsApp sales conversations, qualify leads, and grow your revenue—24/7 on autopilot.
          </p>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {features.map((f, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 10,
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)",
                borderRadius: 10, padding: "10px 14px"
              }}>
                <span style={{ color: f.color }}>{f.icon}</span>
                <span style={{ fontSize: 13, color: "rgb(203,213,225)", fontWeight: 500 }}>{f.text}</span>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 40, display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ display: "flex" }}>
              {["#6366f1", "#8b5cf6", "#ec4899", "#22c55e"].map((color, i) => (
                <div key={i} style={{ width: 32, height: 32, borderRadius: "50%", background: color, border: "2px solid rgb(15,17,26)", marginLeft: i > 0 ? -8 : 0 }} />
              ))}
            </div>
            <div>
              <div style={{ fontSize: 13, color: "white", fontWeight: 600 }}>Join 500+ businesses</div>
              <div style={{ fontSize: 12, color: "rgb(148,163,184)" }}>already automating with SalesAI Pro</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Auth Form */}
      <div style={{ width: 480, display: "flex", alignItems: "center", justifyContent: "center", padding: "40px", position: "relative" }}>
        <div className="glass-card" style={{ width: "100%", padding: "40px" }}>
          {/* Mode Toggle */}
          <div style={{ display: "flex", background: "rgba(30,35,55,0.8)", borderRadius: 10, padding: 4, marginBottom: 28 }}>
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                style={{
                  flex: 1, padding: "8px 16px", borderRadius: 8, border: "none",
                  cursor: "pointer", fontSize: 14, fontWeight: 600,
                  background: mode === m ? "linear-gradient(135deg, #6366f1, #8b5cf6)" : "transparent",
                  color: mode === m ? "white" : "rgb(148,163,184)",
                  transition: "all 0.2s ease",
                }}
              >
                {m === "login" ? "Sign In" : "Get Started"}
              </button>
            ))}
          </div>

          <div style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: "white", marginBottom: 4 }}>
              {mode === "login" ? "Welcome back" : "Create your account"}
            </h2>
            <p style={{ fontSize: 13, color: "rgb(148,163,184)" }}>
              {mode === "login" ? "Sign in to your dashboard" : "Start your 3-day free trial today"}
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {mode === "register" && (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <div>
                      <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>First Name</label>
                      <input
                        className="input-field"
                        type="text"
                        placeholder="John"
                        value={form.firstName}
                        onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                        required={mode === "register"}
                      />
                    </div>
                    <div>
                      <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Last Name</label>
                      <input
                        className="input-field"
                        type="text"
                        placeholder="Doe"
                        value={form.lastName}
                        onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                        required={mode === "register"}
                      />
                    </div>
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Company Name</label>
                    <input
                      className="input-field"
                      type="text"
                      placeholder="Acme Corp"
                      value={form.companyName}
                      onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Phone</label>
                    <input
                      className="input-field"
                      type="tel"
                      placeholder="+92 300 0000000"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    />
                  </div>
                </>
              )}

              <div>
                <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Email Address</label>
                <input
                  className="input-field"
                  type="email"
                  placeholder="john@company.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: 12, color: "rgb(148,163,184)", fontWeight: 600, display: "block", marginBottom: 6, letterSpacing: "0.05em", textTransform: "uppercase" }}>Password</label>
                <div style={{ position: "relative" }}>
                  <input
                    className="input-field"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    required
                    style={{ paddingRight: 44 }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "rgb(148,163,184)" }}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary"
                style={{ width: "100%", padding: "12px", fontSize: 15, marginTop: 4, opacity: loading ? 0.7 : 1 }}
              >
                {loading ? "Please wait..." : mode === "login" ? "Sign In →" : "Start Free Trial →"}
              </button>
            </div>
          </form>

          {mode === "login" && (
            <div style={{ textAlign: "center", marginTop: 20 }}>
              <span style={{ fontSize: 13, color: "rgb(148,163,184)" }}>
                Don&apos;t have an account?{" "}
                <button
                  onClick={() => setMode("register")}
                  style={{ background: "none", border: "none", color: "#8b5cf6", cursor: "pointer", fontWeight: 600, fontSize: 13 }}
                >
                  Create one free
                </button>
              </span>
            </div>
          )}

          {mode === "register" && (
            <div style={{ marginTop: 16, padding: 14, background: "rgba(34,197,94,0.1)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10, display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ color: "#22c55e", fontSize: 18 }}>🎉</div>
              <div>
                <div style={{ fontSize: 13, color: "#22c55e", fontWeight: 600 }}>3-Day Free Trial Included</div>
                <div style={{ fontSize: 12, color: "rgb(148,163,184)" }}>No credit card required</div>
              </div>
            </div>
          )}

          <div style={{ textAlign: "center", marginTop: 20 }}>
            <p style={{ fontSize: 11, color: "rgba(148,163,184,0.6)" }}>
              By continuing, you agree to our Terms of Service & Privacy Policy
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

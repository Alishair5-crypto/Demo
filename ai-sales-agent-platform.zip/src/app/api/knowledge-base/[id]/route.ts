import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { knowledgeBase } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const body = await req.json();

    const [existing] = await db.select().from(knowledgeBase)
      .where(and(eq(knowledgeBase.id, parseInt(id)), eq(knowledgeBase.userId, session.userId)))
      .limit(1);

    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const [updated] = await db.update(knowledgeBase)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(knowledgeBase.id, parseInt(id)))
      .returning();

    return NextResponse.json({ item: updated });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;

    await db.delete(knowledgeBase)
      .where(and(eq(knowledgeBase.id, parseInt(id)), eq(knowledgeBase.userId, session.userId)));

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

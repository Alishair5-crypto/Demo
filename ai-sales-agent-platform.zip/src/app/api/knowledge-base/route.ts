import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { knowledgeBase } from "@/db/schema";
import { eq, and, desc, count, ilike } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type") ?? "";
    const search = searchParams.get("search") ?? "";
    const page = parseInt(searchParams.get("page") ?? "1");
    const limit = parseInt(searchParams.get("limit") ?? "20");
    const offset = (page - 1) * limit;

    const conditions = [eq(knowledgeBase.userId, session.userId)];
    if (type) conditions.push(eq(knowledgeBase.type, type as "product" | "faq" | "pricing" | "company" | "policy"));
    if (search) conditions.push(ilike(knowledgeBase.title, `%${search}%`));

    const where = and(...conditions);
    const [{ total }] = await db.select({ total: count() }).from(knowledgeBase).where(where);

    const data = await db.select().from(knowledgeBase)
      .where(where)
      .orderBy(desc(knowledgeBase.priority), desc(knowledgeBase.createdAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json({ items: data, total, page, limit });
  } catch (error) {
    console.error("Knowledge base GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { type, title, content, tags, priority } = body;

    if (!type || !title || !content) {
      return NextResponse.json({ error: "Type, title, and content are required" }, { status: 400 });
    }

    const [item] = await db.insert(knowledgeBase).values({
      userId: session.userId,
      type,
      title,
      content,
      tags: tags || [],
      priority: priority || 0,
      isActive: true,
    }).returning();

    return NextResponse.json({ item }, { status: 201 });
  } catch (error) {
    console.error("Knowledge base POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

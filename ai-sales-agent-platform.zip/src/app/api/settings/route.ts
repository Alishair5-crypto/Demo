import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const [userSettings] = await db.select().from(settings).where(eq(settings.userId, session.userId)).limit(1);

    // Mask sensitive fields
    if (userSettings) {
      const masked = { ...userSettings };
      if (masked.openaiApiKey) masked.openaiApiKey = "sk-" + "•".repeat(20) + masked.openaiApiKey.slice(-4);
      if (masked.whatsappToken) masked.whatsappToken = "•".repeat(20) + masked.whatsappToken.slice(-4);
      if (masked.stripeSecretKey) masked.stripeSecretKey = "sk_" + "•".repeat(20) + masked.stripeSecretKey.slice(-4);
      return NextResponse.json({ settings: masked });
    }

    return NextResponse.json({ settings: null });
  } catch (error) {
    console.error("Settings GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    // Remove masked values
    const cleanBody = { ...body };
    Object.keys(cleanBody).forEach((key) => {
      const val = cleanBody[key];
      if (typeof val === "string" && val.includes("•")) {
        delete cleanBody[key];
      }
    });

    const [existing] = await db.select().from(settings).where(eq(settings.userId, session.userId)).limit(1);

    if (!existing) {
      const [created] = await db.insert(settings).values({
        userId: session.userId,
        ...cleanBody,
      }).returning();
      return NextResponse.json({ settings: created });
    }

    const [updated] = await db.update(settings)
      .set({ ...cleanBody, updatedAt: new Date() })
      .where(eq(settings.userId, session.userId))
      .returning();

    return NextResponse.json({ settings: updated });
  } catch (error) {
    console.error("Settings PATCH error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

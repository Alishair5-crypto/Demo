import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const customerId = parseInt(id);

    const [customer] = await db.select().from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.userId, session.userId)))
      .limit(1);

    if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

    const customerOrders = await db.select().from(orders)
      .where(and(eq(orders.customerId, customerId), eq(orders.userId, session.userId)))
      .orderBy(desc(orders.createdAt))
      .limit(10);

    return NextResponse.json({ customer, orders: customerOrders });
  } catch (error) {
    console.error("Customer GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const customerId = parseInt(id);
    const body = await req.json();

    const [existing] = await db.select().from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.userId, session.userId)))
      .limit(1);

    if (!existing) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

    const { firstName, lastName, email, phone, whatsappNumber, address, city, country, tags, notes, leadStatus, isActive } = body;

    const [updated] = await db.update(customers)
      .set({
        firstName: firstName ?? existing.firstName,
        lastName: lastName ?? existing.lastName,
        email: email ?? existing.email,
        phone: phone ?? existing.phone,
        whatsappNumber: whatsappNumber ?? existing.whatsappNumber,
        address: address ?? existing.address,
        city: city ?? existing.city,
        country: country ?? existing.country,
        tags: tags ?? existing.tags,
        notes: notes ?? existing.notes,
        leadStatus: leadStatus ?? existing.leadStatus,
        isActive: isActive ?? existing.isActive,
        updatedAt: new Date(),
      })
      .where(eq(customers.id, customerId))
      .returning();

    return NextResponse.json({ customer: updated });
  } catch (error) {
    console.error("Customer PATCH error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const customerId = parseInt(id);

    const [existing] = await db.select().from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.userId, session.userId)))
      .limit(1);

    if (!existing) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

    await db.delete(customers).where(eq(customers.id, customerId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Customer DELETE error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { eq, and, ilike, or, desc, count } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") ?? "";
    const leadStatus = searchParams.get("leadStatus") ?? "";
    const page = parseInt(searchParams.get("page") ?? "1");
    const limit = parseInt(searchParams.get("limit") ?? "20");
    const offset = (page - 1) * limit;

    const conditions = [eq(customers.userId, session.userId)];

    if (search) {
      conditions.push(
        or(
          ilike(customers.firstName, `%${search}%`),
          ilike(customers.lastName, `%${search}%`),
          ilike(customers.email, `%${search}%`),
          ilike(customers.phone, `%${search}%`)
        )!
      );
    }

    if (leadStatus) {
      conditions.push(eq(customers.leadStatus, leadStatus as "new" | "qualified" | "unqualified" | "converted" | "lost"));
    }

    const where = and(...conditions);

    const [{ total }] = await db.select({ total: count() }).from(customers).where(where);

    const data = await db.select().from(customers)
      .where(where)
      .orderBy(desc(customers.createdAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json({ customers: data, total, page, limit, pages: Math.ceil(total / limit) });
  } catch (error) {
    console.error("Customers GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { firstName, lastName, email, phone, whatsappNumber, address, city, country, tags, notes, leadStatus } = body;

    if (!firstName || !lastName || !phone) {
      return NextResponse.json({ error: "First name, last name, and phone are required" }, { status: 400 });
    }

    const [customer] = await db.insert(customers).values({
      userId: session.userId,
      firstName,
      lastName,
      email,
      phone,
      whatsappNumber: whatsappNumber || phone,
      address,
      city,
      country: country || "Pakistan",
      tags: tags || [],
      notes,
      leadStatus: leadStatus || "new",
      source: "manual",
    }).returning();

    return NextResponse.json({ customer }, { status: 201 });
  } catch (error) {
    console.error("Customers POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

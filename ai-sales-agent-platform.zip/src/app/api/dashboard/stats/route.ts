import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders, conversations, notifications, messages } from "@/db/schema";
import { eq, count, sum, gte, desc, and } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const userId = session.userId;
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    const last30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    // Total customers
    const [totalCustomers] = await db.select({ count: count() }).from(customers).where(eq(customers.userId, userId));
    const [newCustomersThisMonth] = await db.select({ count: count() }).from(customers).where(and(eq(customers.userId, userId), gte(customers.createdAt, startOfMonth)));
    const [newCustomersLastMonth] = await db.select({ count: count() }).from(customers).where(and(eq(customers.userId, userId), gte(customers.createdAt, startOfLastMonth)));

    // Orders
    const [totalOrders] = await db.select({ count: count() }).from(orders).where(eq(orders.userId, userId));
    const [pendingOrders] = await db.select({ count: count() }).from(orders).where(and(eq(orders.userId, userId), eq(orders.status, "pending")));
    const [completedOrders] = await db.select({ count: count() }).from(orders).where(and(eq(orders.userId, userId), eq(orders.status, "completed")));

    // Revenue
    const [totalRevenue] = await db.select({ total: sum(orders.total) }).from(orders).where(and(eq(orders.userId, userId), eq(orders.paymentStatus, "completed")));
    const [monthRevenue] = await db.select({ total: sum(orders.total) }).from(orders).where(and(eq(orders.userId, userId), eq(orders.paymentStatus, "completed"), gte(orders.createdAt, startOfMonth)));
    const [lastMonthRevenue] = await db.select({ total: sum(orders.total) }).from(orders).where(and(eq(orders.userId, userId), eq(orders.paymentStatus, "completed"), gte(orders.createdAt, startOfLastMonth)));

    // Conversations
    const [totalConversations] = await db.select({ count: count() }).from(conversations).where(eq(conversations.userId, userId));
    const [activeConversations] = await db.select({ count: count() }).from(conversations).where(and(eq(conversations.userId, userId), gte(conversations.updatedAt, last7Days)));

    // AI messages
    const [aiMessages] = await db.select({ count: count() }).from(messages).where(and(eq(messages.isAiGenerated, true), gte(messages.createdAt, last30Days)));

    // Unread notifications
    const [unreadNotifs] = await db.select({ count: count() }).from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));

    // Recent orders
    const recentOrders = await db.select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      total: orders.total,
      paymentStatus: orders.paymentStatus,
      createdAt: orders.createdAt,
    }).from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt)).limit(5);

    // Monthly revenue trend (last 6 months)
    const revenueByMonth: { month: string; revenue: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
      const [rev] = await db.select({ total: sum(orders.total) }).from(orders).where(
        and(
          eq(orders.userId, userId),
          gte(orders.createdAt, start),
          // end of month check not available in drizzle simple, use raw or date bounds
        )
      );
      revenueByMonth.push({
        month: start.toLocaleString("default", { month: "short" }),
        revenue: parseFloat(rev?.total ?? "0") || 0,
      });
    }

    // Orders by status
    const ordersByStatus = [
      { status: "pending", count: pendingOrders.count },
      { status: "completed", count: completedOrders.count },
      { status: "cancelled", count: 0 },
      { status: "delivered", count: 0 },
    ];

    // Conversion rate
    const qualifiedLeads = await db.select({ count: count() }).from(customers).where(and(eq(customers.userId, userId), eq(customers.leadStatus, "qualified")));
    const convertedLeads = await db.select({ count: count() }).from(customers).where(and(eq(customers.userId, userId), eq(customers.leadStatus, "converted")));
    const conversionRate = qualifiedLeads[0].count > 0 ? Math.round((convertedLeads[0].count / qualifiedLeads[0].count) * 100) : 0;

    const currentMonthRevenue = parseFloat(monthRevenue.total ?? "0") || 0;
    const lastMonthRevenueVal = parseFloat(lastMonthRevenue.total ?? "0") || 0;
    const revenueGrowth = lastMonthRevenueVal > 0 ? Math.round(((currentMonthRevenue - lastMonthRevenueVal) / lastMonthRevenueVal) * 100) : 0;

    const newCustomersGrowth = newCustomersLastMonth.count > 0 ? Math.round(((newCustomersThisMonth.count - newCustomersLastMonth.count) / newCustomersLastMonth.count) * 100) : 0;

    return NextResponse.json({
      stats: {
        totalCustomers: totalCustomers.count,
        newCustomersThisMonth: newCustomersThisMonth.count,
        customersGrowth: newCustomersGrowth,
        totalOrders: totalOrders.count,
        pendingOrders: pendingOrders.count,
        completedOrders: completedOrders.count,
        totalRevenue: parseFloat(totalRevenue.total ?? "0") || 0,
        monthRevenue: currentMonthRevenue,
        revenueGrowth,
        totalConversations: totalConversations.count,
        activeConversations: activeConversations.count,
        aiMessages: aiMessages.count,
        unreadNotifications: unreadNotifs.count,
        conversionRate,
      },
      recentOrders,
      revenueByMonth,
      ordersByStatus,
    });
  } catch (error) {
    console.error("Dashboard stats error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

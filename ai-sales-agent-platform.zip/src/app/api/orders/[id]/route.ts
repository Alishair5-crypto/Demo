import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, customers } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);

    const [order] = await db.select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      items: orders.items,
      subtotal: orders.subtotal,
      tax: orders.tax,
      discount: orders.discount,
      total: orders.total,
      paymentStatus: orders.paymentStatus,
      paymentMethod: orders.paymentMethod,
      notes: orders.notes,
      deliveryAddress: orders.deliveryAddress,
      deliveredAt: orders.deliveredAt,
      createdAt: orders.createdAt,
      updatedAt: orders.updatedAt,
      customerId: orders.customerId,
      customerFirstName: customers.firstName,
      customerLastName: customers.lastName,
      customerPhone: customers.phone,
      customerEmail: customers.email,
    }).from(orders)
      .leftJoin(customers, eq(orders.customerId, customers.id))
      .where(and(eq(orders.id, orderId), eq(orders.userId, session.userId)))
      .limit(1);

    if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });

    return NextResponse.json({ order });
  } catch (error) {
    console.error("Order GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);
    const body = await req.json();

    const [existing] = await db.select().from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, session.userId)))
      .limit(1);

    if (!existing) return NextResponse.json({ error: "Order not found" }, { status: 404 });

    const { status, paymentStatus, paymentMethod, notes, deliveryAddress, deliveredAt } = body;

    const updateData: Partial<typeof existing> = {
      updatedAt: new Date(),
    };

    if (status) updateData.status = status;
    if (paymentStatus) updateData.paymentStatus = paymentStatus;
    if (paymentMethod) updateData.paymentMethod = paymentMethod;
    if (notes !== undefined) updateData.notes = notes;
    if (deliveryAddress !== undefined) updateData.deliveryAddress = deliveryAddress;
    if (status === "delivered") updateData.deliveredAt = new Date();

    const [updated] = await db.update(orders)
      .set(updateData)
      .where(eq(orders.id, orderId))
      .returning();

    // Update customer total spent if payment completed
    if (paymentStatus === "completed") {
      const [customer] = await db.select().from(customers).where(eq(customers.id, existing.customerId)).limit(1);
      if (customer) {
        await db.update(customers).set({
          totalSpent: String(parseFloat(customer.totalSpent ?? "0") + parseFloat(existing.total)),
          updatedAt: new Date(),
        }).where(eq(customers.id, existing.customerId));
      }
    }

    return NextResponse.json({ order: updated });
  } catch (error) {
    console.error("Order PATCH error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);

    const [existing] = await db.select().from(orders)
      .where(and(eq(orders.id, orderId), eq(orders.userId, session.userId)))
      .limit(1);

    if (!existing) return NextResponse.json({ error: "Order not found" }, { status: 404 });

    await db.delete(orders).where(eq(orders.id, orderId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Order DELETE error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, customers } from "@/db/schema";
import { eq, and, desc, count, ilike, or } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { generateOrderNumber } from "@/lib/utils";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") ?? "";
    const search = searchParams.get("search") ?? "";
    const page = parseInt(searchParams.get("page") ?? "1");
    const limit = parseInt(searchParams.get("limit") ?? "20");
    const offset = (page - 1) * limit;

    const conditions = [eq(orders.userId, session.userId)];
    if (status) conditions.push(eq(orders.status, status as "pending" | "confirmed" | "processing" | "delivered" | "completed" | "cancelled"));

    const where = and(...conditions);

    const [{ total }] = await db.select({ total: count() }).from(orders).where(where);

    const data = await db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        status: orders.status,
        items: orders.items,
        subtotal: orders.subtotal,
        tax: orders.tax,
        discount: orders.discount,
        total: orders.total,
        paymentStatus: orders.paymentStatus,
        paymentMethod: orders.paymentMethod,
        notes: orders.notes,
        deliveryAddress: orders.deliveryAddress,
        deliveredAt: orders.deliveredAt,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
        customerId: orders.customerId,
        customerFirstName: customers.firstName,
        customerLastName: customers.lastName,
        customerPhone: customers.phone,
      })
      .from(orders)
      .leftJoin(customers, eq(orders.customerId, customers.id))
      .where(where)
      .orderBy(desc(orders.createdAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json({ orders: data, total, page, limit, pages: Math.ceil(total / limit) });
  } catch (error) {
    console.error("Orders GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { customerId, items, tax, discount, notes, deliveryAddress, paymentMethod } = body;

    if (!customerId || !items || items.length === 0) {
      return NextResponse.json({ error: "Customer and items are required" }, { status: 400 });
    }

    // Verify customer belongs to user
    const [customer] = await db.select().from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.userId, session.userId)))
      .limit(1);

    if (!customer) return NextResponse.json({ error: "Customer not found" }, { status: 404 });

    const subtotal = items.reduce((sum: number, item: { total: number }) => sum + item.total, 0);
    const taxAmount = parseFloat(tax ?? 0);
    const discountAmount = parseFloat(discount ?? 0);
    const total = subtotal + taxAmount - discountAmount;

    const [order] = await db.insert(orders).values({
      userId: session.userId,
      customerId,
      orderNumber: generateOrderNumber(),
      status: "pending",
      items,
      subtotal: subtotal.toFixed(2),
      tax: taxAmount.toFixed(2),
      discount: discountAmount.toFixed(2),
      total: total.toFixed(2),
      notes,
      deliveryAddress,
      paymentMethod,
      paymentStatus: "pending",
    }).returning();

    // Update customer totals
    await db.update(customers).set({
      totalOrders: (customer.totalOrders ?? 0) + 1,
      updatedAt: new Date(),
    }).where(eq(customers.id, customerId));

    return NextResponse.json({ order }, { status: 201 });
  } catch (error) {
    console.error("Orders POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

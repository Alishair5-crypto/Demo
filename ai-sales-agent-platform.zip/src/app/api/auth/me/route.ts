import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, subscriptions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const [user] = await db.select({
      id: users.id,
      email: users.email,
      firstName: users.firstName,
      lastName: users.lastName,
      role: users.role,
      companyName: users.companyName,
      companyLogo: users.companyLogo,
      phone: users.phone,
      timezone: users.timezone,
      language: users.language,
      theme: users.theme,
    }).from(users).where(eq(users.id, session.userId)).limit(1);

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Get subscription
    const [subscription] = await db.select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, session.userId))
      .orderBy(subscriptions.createdAt)
      .limit(1);

    return NextResponse.json({ user, subscription });
  } catch (error) {
    console.error("Me error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

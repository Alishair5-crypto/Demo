import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, subscriptions, settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, setSession } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, firstName, lastName, companyName, phone } = body;

    if (!email || !password || !firstName || !lastName) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: "Password must be at least 8 characters" },
        { status: 400 }
      );
    }

    // Check if user exists
    const existing = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: "Email already registered" },
        { status: 409 }
      );
    }

    const hashedPassword = await hashPassword(password);

    // Create user
    const [newUser] = await db.insert(users).values({
      email: email.toLowerCase(),
      password: hashedPassword,
      firstName,
      lastName,
      companyName,
      phone,
      role: "admin",
      isActive: true,
    }).returning();

    // Create trial subscription (3 days)
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + 3);

    await db.insert(subscriptions).values({
      userId: newUser.id,
      plan: "trial",
      status: "active",
      trialEndsAt: trialEnd,
      endDate: trialEnd,
      features: {
        maxCustomers: 50,
        maxOrders: 100,
        whatsappMessages: 500,
        aiResponses: 100,
        teamMembers: 1,
      },
    });

    // Create default settings
    await db.insert(settings).values({
      userId: newUser.id,
      openaiModel: "gpt-4o-mini",
      openaiSystemPrompt: `You are a professional AI sales agent. Your role is to:
1. Greet customers warmly and understand their needs
2. Recommend products based on customer requirements
3. Answer questions about products, pricing, and policies
4. Qualify leads by asking relevant questions
5. Guide customers through the purchase process
6. Follow up on pending orders and inquiries
Be professional, helpful, and concise in your responses.`,
      aiAutoReply: true,
      aiLeadQualification: true,
      aiFollowUp: true,
      followUpDelayHours: 24,
    });

    // Set session
    await setSession({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role,
      companyName: companyName,
    });

    return NextResponse.json({
      success: true,
      user: {
        id: newUser.id,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        role: newUser.role,
        companyName: newUser.companyName,
      },
    });
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

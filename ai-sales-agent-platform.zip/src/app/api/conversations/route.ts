import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages, customers } from "@/db/schema";
import { eq, and, desc, count } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get("page") ?? "1");
    const limit = parseInt(searchParams.get("limit") ?? "20");
    const offset = (page - 1) * limit;

    const [{ total }] = await db.select({ total: count() }).from(conversations)
      .where(eq(conversations.userId, session.userId));

    const data = await db.select({
      id: conversations.id,
      whatsappNumber: conversations.whatsappNumber,
      contactName: conversations.contactName,
      lastMessage: conversations.lastMessage,
      lastMessageAt: conversations.lastMessageAt,
      unreadCount: conversations.unreadCount,
      isAiManaged: conversations.isAiManaged,
      leadStatus: conversations.leadStatus,
      createdAt: conversations.createdAt,
      customerId: conversations.customerId,
      customerFirstName: customers.firstName,
      customerLastName: customers.lastName,
    }).from(conversations)
      .leftJoin(customers, eq(conversations.customerId, customers.id))
      .where(eq(conversations.userId, session.userId))
      .orderBy(desc(conversations.lastMessageAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json({ conversations: data, total });
  } catch (error) {
    console.error("Conversations GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { whatsappNumber, contactName, customerId } = body;

    if (!whatsappNumber) return NextResponse.json({ error: "WhatsApp number required" }, { status: 400 });

    const [conversation] = await db.insert(conversations).values({
      userId: session.userId,
      whatsappNumber,
      contactName,
      customerId,
      isAiManaged: true,
    }).returning();

    return NextResponse.json({ conversation }, { status: 201 });
  } catch (error) {
    console.error("Conversations POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

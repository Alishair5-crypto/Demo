import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messages, conversations } from "@/db/schema";
import { eq, and, asc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const conversationId = parseInt(id);

    // Verify conversation belongs to user
    const [conv] = await db.select().from(conversations)
      .where(and(eq(conversations.id, conversationId), eq(conversations.userId, session.userId)))
      .limit(1);

    if (!conv) return NextResponse.json({ error: "Conversation not found" }, { status: 404 });

    const data = await db.select().from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.sentAt))
      .limit(100);

    // Reset unread count
    await db.update(conversations)
      .set({ unreadCount: 0 })
      .where(eq(conversations.id, conversationId));

    return NextResponse.json({ messages: data, conversation: conv });
  } catch (error) {
    console.error("Messages GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { id } = await params;
    const conversationId = parseInt(id);
    const body = await req.json();
    const { content, direction, isAiGenerated, messageType } = body;

    if (!content) return NextResponse.json({ error: "Content required" }, { status: 400 });

    // Verify conversation
    const [conv] = await db.select().from(conversations)
      .where(and(eq(conversations.id, conversationId), eq(conversations.userId, session.userId)))
      .limit(1);

    if (!conv) return NextResponse.json({ error: "Conversation not found" }, { status: 404 });

    const [msg] = await db.insert(messages).values({
      conversationId,
      userId: session.userId,
      direction: direction || "outbound",
      messageType: messageType || "text",
      content,
      isAiGenerated: isAiGenerated || false,
      status: "sent",
    }).returning();

    // Update conversation last message
    await db.update(conversations).set({
      lastMessage: content.substring(0, 100),
      lastMessageAt: new Date(),
      updatedAt: new Date(),
      unreadCount: direction === "inbound" ? (conv.unreadCount ?? 0) + 1 : conv.unreadCount,
    }).where(eq(conversations.id, conversationId));

    return NextResponse.json({ message: msg }, { status: 201 });
  } catch (error) {
    console.error("Messages POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

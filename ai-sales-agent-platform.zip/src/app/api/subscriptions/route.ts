import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { subscriptions, payments } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { generateInvoiceNumber } from "@/lib/utils";

const PLANS = {
  silver: {
    name: "Silver",
    monthlyPrice: 2999,
    features: {
      maxCustomers: 500,
      maxOrders: 1000,
      whatsappMessages: 5000,
      aiResponses: 1000,
      teamMembers: 3,
      googleSheets: true,
      analytics: true,
      reports: true,
    },
  },
  gold: {
    name: "Gold",
    monthlyPrice: 5999,
    features: {
      maxCustomers: 2000,
      maxOrders: 5000,
      whatsappMessages: 20000,
      aiResponses: 5000,
      teamMembers: 10,
      googleSheets: true,
      analytics: true,
      reports: true,
      broadcasts: true,
      prioritySupport: true,
    },
  },
  diamond: {
    name: "Diamond",
    monthlyPrice: 9999,
    features: {
      maxCustomers: -1, // unlimited
      maxOrders: -1,
      whatsappMessages: -1,
      aiResponses: -1,
      teamMembers: -1,
      googleSheets: true,
      analytics: true,
      reports: true,
      broadcasts: true,
      prioritySupport: true,
      customIntegrations: true,
      dedicatedManager: true,
    },
  },
};

export async function GET() {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const [subscription] = await db.select().from(subscriptions)
      .where(eq(subscriptions.userId, session.userId))
      .orderBy(desc(subscriptions.createdAt))
      .limit(1);

    const paymentHistory = await db.select().from(payments)
      .where(eq(payments.userId, session.userId))
      .orderBy(desc(payments.createdAt))
      .limit(10);

    return NextResponse.json({ subscription, plans: PLANS, paymentHistory });
  } catch (error) {
    console.error("Subscriptions GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { plan, paymentMethod, transactionId } = body;

    if (!plan || !paymentMethod) {
      return NextResponse.json({ error: "Plan and payment method required" }, { status: 400 });
    }

    const planData = PLANS[plan as keyof typeof PLANS];
    if (!planData) return NextResponse.json({ error: "Invalid plan" }, { status: 400 });

    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1);

    // Deactivate existing subscriptions
    await db.update(subscriptions)
      .set({ status: "cancelled" })
      .where(eq(subscriptions.userId, session.userId));

    // Create new subscription
    const [subscription] = await db.insert(subscriptions).values({
      userId: session.userId,
      plan: plan as "silver" | "gold" | "diamond",
      status: "active",
      startDate: new Date(),
      endDate,
      monthlyPrice: String(planData.monthlyPrice),
      features: planData.features,
      autoRenew: true,
    }).returning();

    // Record payment
    await db.insert(payments).values({
      userId: session.userId,
      subscriptionId: subscription.id,
      amount: String(planData.monthlyPrice),
      currency: "PKR",
      method: paymentMethod as "jazzcash" | "easypaisa" | "stripe" | "bank_transfer",
      status: "pending",
      transactionId,
      invoiceNumber: generateInvoiceNumber(),
    });

    return NextResponse.json({ subscription }, { status: 201 });
  } catch (error) {
    console.error("Subscriptions POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

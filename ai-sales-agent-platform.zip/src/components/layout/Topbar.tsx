"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/store/useStore";
import { Bell, Menu, Sun, Moon, Search } from "lucide-react";
import Link from "next/link";

export default function Topbar({ title }: { title?: string }) {
  const router = useRouter();
  const { theme, setTheme, toggleSidebar, user } = useStore();
  const [unreadCount, setUnreadCount] = useState(0);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    fetch("/api/notifications?unread=true&limit=1")
      .then(r => r.json())
      .then(d => setUnreadCount(d.unreadCount || 0))
      .catch(() => {});
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    document.documentElement.classList.toggle("light", newTheme === "light");
  };

  return (
    <header className="topbar" style={{ paddingLeft: 284, gap: 16 }}>
      <button
        onClick={toggleSidebar}
        style={{ background: "none", border: "none", color: "rgb(148,163,184)", cursor: "pointer", padding: 6, borderRadius: 8, display: "flex" }}
      >
        <Menu size={20} />
      </button>

      {title && (
        <h1 style={{ fontSize: 16, fontWeight: 700, color: "white", flex: 0 }}>
          {title}
        </h1>
      )}

      <div style={{ flex: 1, maxWidth: 360, position: "relative" }}>
        {showSearch ? (
          <input
            autoFocus
            className="input-field"
            placeholder="Search anything..."
            onBlur={() => setShowSearch(false)}
            style={{ paddingLeft: 36, height: 36 }}
          />
        ) : (
          <button
            onClick={() => setShowSearch(true)}
            style={{ display: "flex", alignItems: "center", gap: 8, background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 8, padding: "7px 14px", cursor: "pointer", color: "rgb(100,116,139)", fontSize: 13 }}
          >
            <Search size={14} />
            <span>Search...</span>
            <kbd style={{ marginLeft: "auto", fontSize: 10, background: "rgba(255,255,255,0.06)", borderRadius: 4, padding: "2px 6px", color: "rgb(100,116,139)" }}>⌘K</kbd>
          </button>
        )}
        {showSearch && <Search size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "rgb(100,116,139)" }} />}
      </div>

      <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 8, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "rgb(148,163,184)" }}
        >
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        {/* Notifications */}
        <Link href="/dashboard/notifications" style={{ position: "relative", textDecoration: "none" }}>
          <button style={{ background: "rgba(30,35,55,0.6)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 8, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "rgb(148,163,184)" }}>
            <Bell size={16} />
            {unreadCount > 0 && (
              <span style={{ position: "absolute", top: -4, right: -4, background: "#ef4444", color: "white", borderRadius: "50%", width: 18, height: 18, fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid rgb(15,17,26)" }}>
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>
        </Link>

        {/* User avatar */}
        {user && (
          <Link href="/dashboard/profile" style={{ textDecoration: "none" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white", cursor: "pointer" }}>
              {user.firstName?.[0]}{user.lastName?.[0]}
            </div>
          </Link>
        )}
      </div>
    </header>
  );
}

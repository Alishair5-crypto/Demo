"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useStore } from "@/store/useStore";
import toast from "react-hot-toast";
import {
  LayoutDashboard, Users, Package, MessageSquare, Bot,
  BarChart3, FileText, BookOpen, Bell, User, Settings,
  CreditCard, Crown, LogOut, X, ChevronRight,
} from "lucide-react";

const navItems = [
  { href: "/dashboard", icon: <LayoutDashboard size={18} />, label: "Dashboard", color: "#6366f1" },
  { href: "/dashboard/customers", icon: <Users size={18} />, label: "Customers", color: "#8b5cf6" },
  { href: "/dashboard/orders", icon: <Package size={18} />, label: "Orders", color: "#ec4899" },
  { href: "/dashboard/whatsapp", icon: <MessageSquare size={18} />, label: "WhatsApp", color: "#22c55e" },
  { href: "/dashboard/ai", icon: <Bot size={18} />, label: "AI Assistant", color: "#f59e0b" },
  { href: "/dashboard/analytics", icon: <BarChart3 size={18} />, label: "Analytics", color: "#3b82f6" },
  { href: "/dashboard/reports", icon: <FileText size={18} />, label: "Reports", color: "#14b8a6" },
  { href: "/dashboard/knowledge-base", icon: <BookOpen size={18} />, label: "Knowledge Base", color: "#f97316" },
  { href: "/dashboard/notifications", icon: <Bell size={18} />, label: "Notifications", color: "#a855f7" },
];

const bottomItems = [
  { href: "/dashboard/profile", icon: <User size={18} />, label: "Profile", color: "#64748b" },
  { href: "/dashboard/settings", icon: <Settings size={18} />, label: "Settings", color: "#64748b" },
  { href: "/dashboard/subscriptions", icon: <Crown size={18} />, label: "Subscription", color: "#f59e0b" },
  { href: "/dashboard/payments", icon: <CreditCard size={18} />, label: "Payments", color: "#22c55e" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, sidebarOpen, setSidebarOpen } = useStore();

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    useStore.getState().setUser(null);
    toast.success("Logged out successfully");
    router.push("/auth");
  };

  if (!sidebarOpen) return null;

  return (
    <>
      {/* Mobile overlay */}
      <div
        className="md:hidden fixed inset-0 bg-black/60 z-40"
        onClick={() => setSidebarOpen(false)}
      />

      <aside className="sidebar" style={{ overflowY: "auto" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div className="animated-gradient" style={{ width: 36, height: 36, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Bot size={18} color="white" />
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 800, color: "white", letterSpacing: "-0.3px" }}>SalesAI Pro</div>
              <div style={{ fontSize: 10, color: "rgba(148,163,184,0.7)", letterSpacing: "0.05em", textTransform: "uppercase" }}>AI Platform</div>
            </div>
          </div>
          <button
            className="md:hidden"
            onClick={() => setSidebarOpen(false)}
            style={{ background: "none", border: "none", color: "rgb(148,163,184)", cursor: "pointer" }}
          >
            <X size={18} />
          </button>
        </div>

        {/* User info */}
        {user && (
          <div style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 12, padding: "12px 14px", marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white", flexShrink: 0 }}>
                {user.firstName?.[0]}{user.lastName?.[0]}
              </div>
              <div style={{ overflow: "hidden" }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "white", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {user.firstName} {user.lastName}
                </div>
                <div style={{ fontSize: 11, color: "rgb(148,163,184)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {user.companyName || user.email}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Navigation */}
        <nav style={{ flex: 1 }}>
          <div style={{ fontSize: 10, color: "rgba(148,163,184,0.5)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8, paddingLeft: 4 }}>Main Menu</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {navItems.map((item) => {
              const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href} className={`nav-item ${isActive ? "active" : ""}`}>
                  <span style={{ color: isActive ? item.color : "rgb(148,163,184)", transition: "color 0.2s" }}>
                    {item.icon}
                  </span>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {isActive && <ChevronRight size={14} style={{ color: item.color }} />}
                </Link>
              );
            })}
          </div>

          <div style={{ margin: "16px 0", borderTop: "1px solid rgba(255,255,255,0.05)" }} />

          <div style={{ fontSize: 10, color: "rgba(148,163,184,0.5)", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8, paddingLeft: 4 }}>Account</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {bottomItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link key={item.href} href={item.href} className={`nav-item ${isActive ? "active" : ""}`}>
                  <span style={{ color: isActive ? item.color : "rgb(148,163,184)" }}>
                    {item.icon}
                  </span>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {isActive && <ChevronRight size={14} style={{ color: item.color }} />}
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Logout */}
        <div style={{ marginTop: "auto", paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <button
            onClick={handleLogout}
            className="nav-item"
            style={{ width: "100%", cursor: "pointer", background: "none", border: "none", color: "rgb(148,163,184)" }}
          >
            <LogOut size={18} style={{ color: "#ef4444" }} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
}

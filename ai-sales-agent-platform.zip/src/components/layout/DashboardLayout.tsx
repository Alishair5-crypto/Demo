"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/store/useStore";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const router = useRouter();
  const { setUser, theme } = useStore();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Apply theme class
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  useEffect(() => {
    fetch("/api/auth/me")
      .then(r => r.json())
      .then(data => {
        if (data.error) {
          router.push("/auth");
        } else {
          setUser(data.user);
          setLoading(false);
        }
      })
      .catch(() => router.push("/auth"));
  }, [router, setUser]);

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: "rgb(15,17,26)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div className="animated-gradient" style={{ width: 48, height: 48, borderRadius: 14, margin: "0 auto 16px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="white"/>
            </svg>
          </div>
          <div style={{ fontSize: 14, color: "rgb(148,163,184)" }}>Loading SalesAI Pro...</div>
          <div style={{ marginTop: 16, width: 200, margin: "16px auto 0" }}>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: "70%", animation: "none" }} />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "rgb(var(--background))" }}>
      <Sidebar />
      <div style={{ marginLeft: 260, minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Topbar title={title} />
        <main style={{ flex: 1, padding: "28px 28px" }}>
          {children}
        </main>
      </div>
    </div>
  );
}

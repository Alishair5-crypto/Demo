"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  companyName?: string;
  companyLogo?: string;
  phone?: string;
}

interface AppStore {
  user: User | null;
  theme: "dark" | "light";
  sidebarOpen: boolean;
  activeModule: string;
  setUser: (user: User | null) => void;
  setTheme: (theme: "dark" | "light") => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  setActiveModule: (module: string) => void;
}

export const useStore = create<AppStore>()(
  persist(
    (set) => ({
      user: null,
      theme: "dark",
      sidebarOpen: true,
      activeModule: "dashboard",
      setUser: (user) => set({ user }),
      setTheme: (theme) => set({ theme }),
      toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setActiveModule: (module) => set({ activeModule: module }),
    }),
    {
      name: "ai-sales-agent-store",
      partialize: (state) => ({ theme: state.theme, user: state.user }),
    }
  )
);
